import { beforeEach, describe, expect, it } from 'vitest';
import { DAY, LOAN_DAYS, MAX_ACTIVE_BORROWS } from '../src/config.js';
import {
  approveRequest, ensureReminders, notifyWishlist, rejectRequest, requestBook, returnRequest, reviewExchange, shiftDueDate,
} from '../src/services/exchange.js';
import { getBook, getRequest, userTrust } from '../src/queries.js';
import { addBook, addUser, errorStatus, makeDb } from './helpers.js';

let db, lender, borrower, other, bookId;
beforeEach(() => {
  db = makeDb();
  lender = addUser(db, 'Aarav');
  borrower = addUser(db, 'Meera');
  other = addUser(db, 'Kabir');
  bookId = addBook(db, lender.id);
});
const status = (id = bookId) => getBook(db, id).status;

describe('borrow request', () => {
  it('flips the book to reserved immediately and creates a pending request', () => {
    const id = requestBook(db, borrower, bookId, 'library lobby?');
    expect(status()).toBe('reserved');
    expect(getRequest(db, id, borrower.id).status).toBe('pending');
  });

  it('rejects a second request on the same book (no double-borrow)', () => {
    requestBook(db, borrower, bookId);
    expect(errorStatus(() => requestBook(db, other, bookId))).toBe(409);
    expect(db.prepare('SELECT COUNT(*) AS n FROM requests').get().n).toBe(1);
  });

  it('database itself refuses two open requests for one book', () => {
    requestBook(db, borrower, bookId);
    const insert = () => db.prepare("INSERT INTO requests (book_id, lender_id, borrower_id, status, requested_at) VALUES (?, ?, ?, 'pending', ?)")
      .run(bookId, lender.id, other.id, Date.now());
    expect(errorStatus(insert)).toBe('unexpected'); // UNIQUE index violation
  });

  it('does not let owners borrow their own book', () => {
    expect(errorStatus(() => requestBook(db, lender, bookId))).toBe(400);
  });

  it('returns 404 for an unknown book', () => {
    expect(errorStatus(() => requestBook(db, borrower, 999))).toBe(404);
  });

  it(`caps active requests per borrower at ${MAX_ACTIVE_BORROWS}`, () => {
    for (let i = 0; i < MAX_ACTIVE_BORROWS; i++) requestBook(db, borrower, addBook(db, lender.id));
    expect(errorStatus(() => requestBook(db, borrower, addBook(db, lender.id)))).toBe(409);
  });
});

describe('approve / reject', () => {
  it('approve sets a 7-day due date and flips the book to borrowed', () => {
    const id = requestBook(db, borrower, bookId);
    approveRequest(db, lender, id);
    const r = getRequest(db, id, lender.id);
    expect(r.status).toBe('approved');
    expect(r.dueDate - r.approvedAt).toBe(LOAN_DAYS * DAY);
    expect(status()).toBe('borrowed');
  });

  it('only the lender can approve or reject', () => {
    const id = requestBook(db, borrower, bookId);
    expect(errorStatus(() => approveRequest(db, borrower, id))).toBe(403);
    expect(errorStatus(() => rejectRequest(db, other, id))).toBe(403);
    expect(status()).toBe('reserved');
  });

  it('cannot approve twice', () => {
    const id = requestBook(db, borrower, bookId);
    approveRequest(db, lender, id);
    expect(errorStatus(() => approveRequest(db, lender, id))).toBe(409);
  });

  it('reject frees the book and notifies the borrower', () => {
    const id = requestBook(db, borrower, bookId);
    rejectRequest(db, lender, id);
    expect(status()).toBe('available');
    expect(db.prepare("SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND type = 'rejected'").get(borrower.id).n).toBe(1);
  });
});

describe('return', () => {
  it('on-time return frees the book and records onTime=true', () => {
    const id = requestBook(db, borrower, bookId);
    approveRequest(db, lender, id);
    returnRequest(db, borrower, id);
    const r = getRequest(db, id, borrower.id);
    expect(r.status).toBe('returned');
    expect(r.onTime).toBe(true);
    expect(status()).toBe('available');
  });

  it('late return records onTime=false', () => {
    const id = requestBook(db, borrower, bookId);
    approveRequest(db, lender, id);
    shiftDueDate(db, borrower, id, -1);
    returnRequest(db, lender, id);
    expect(getRequest(db, id, lender.id).onTime).toBe(false);
  });

  it('strangers cannot return; pending requests cannot be returned', () => {
    const id = requestBook(db, borrower, bookId);
    expect(errorStatus(() => returnRequest(db, borrower, id))).toBe(409);
    approveRequest(db, lender, id);
    expect(errorStatus(() => returnRequest(db, other, id))).toBe(403);
  });
});

describe('contact privacy', () => {
  it('hides emails until the request is approved', () => {
    const id = requestBook(db, borrower, bookId);
    expect(getRequest(db, id, lender.id).borrower.email).toBeNull();
    approveRequest(db, lender, id);
    expect(getRequest(db, id, lender.id).borrower.email).toBe(borrower.email);
  });
});

describe('reminders', () => {
  it('creates due-soon and overdue notifications once (idempotent)', () => {
    const id = requestBook(db, borrower, bookId);
    approveRequest(db, lender, id);
    const due = getRequest(db, id, lender.id).dueDate;

    ensureReminders(db, due - 3 * DAY); // not yet
    expect(db.prepare('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ?').get(borrower.id).n).toBe(1); // approval only

    ensureReminders(db, due - DAY);
    ensureReminders(db, due - DAY);
    expect(db.prepare("SELECT COUNT(*) AS n FROM notifications WHERE type = 'reminder'").get().n).toBe(1);

    ensureReminders(db, due + DAY);
    ensureReminders(db, due + DAY);
    expect(db.prepare("SELECT COUNT(*) AS n FROM notifications WHERE type = 'overdue'").get().n).toBe(2); // borrower + lender
  });
});

describe('ratings', () => {
  const finish = () => {
    const id = requestBook(db, borrower, bookId);
    approveRequest(db, lender, id);
    returnRequest(db, borrower, id);
    return id;
  };

  it('both parties can rate once after return and trust score averages', () => {
    const id = finish();
    reviewExchange(db, borrower, id, { rating: 5, comment: 'Great lender' });
    reviewExchange(db, lender, id, { rating: 3, comment: '' });
    expect(userTrust(db, lender.id)).toEqual({ rating: 5, ratingCount: 1 });
    expect(userTrust(db, borrower.id)).toEqual({ rating: 3, ratingCount: 1 });
    expect(errorStatus(() => reviewExchange(db, borrower, id, { rating: 1, comment: '' }))).toBe(409);
  });

  it('cannot rate before return or as a stranger', () => {
    const id = requestBook(db, borrower, bookId);
    approveRequest(db, lender, id);
    expect(errorStatus(() => reviewExchange(db, borrower, id, { rating: 4, comment: '' }))).toBe(409);
    returnRequest(db, borrower, id);
    expect(errorStatus(() => reviewExchange(db, other, id, { rating: 4, comment: '' }))).toBe(403);
  });
});

describe('wishlist', () => {
  it('notifies watchers when a book for their course becomes available again', () => {
    db.prepare('INSERT INTO wishlist (user_id, course_code) VALUES (?, ?)').run(other.id, 'CS301');
    const id = requestBook(db, borrower, bookId);
    approveRequest(db, lender, id);
    returnRequest(db, borrower, id);
    expect(db.prepare("SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND type = 'wishlist'").get(other.id).n).toBe(1);
  });

  it('does not notify the owner of the book', () => {
    db.prepare('INSERT INTO wishlist (user_id, course_code) VALUES (?, ?)').run(lender.id, 'CS301');
    notifyWishlist(db, db.prepare('SELECT * FROM books WHERE id = ?').get(bookId));
    expect(db.prepare("SELECT COUNT(*) AS n FROM notifications WHERE type = 'wishlist'").get().n).toBe(0);
  });
});
