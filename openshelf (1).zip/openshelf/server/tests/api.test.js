import request from 'supertest';
import { beforeEach, describe, expect, it } from 'vitest';
import { createApp } from '../src/app.js';
import { seedDatabase } from '../src/seed.js';
import { makeDb } from './helpers.js';

let app, db;
const fakeFetch = async (url) => ({
  ok: true,
  json: async () => ({ 'ISBN:9781119800361': { title: 'Operating System Concepts', authors: [{ name: 'Abraham Silberschatz' }], publish_date: '2021', cover: { medium: 'https://x/y.jpg' } } }),
});

beforeEach(async () => {
  db = makeDb();
  await seedDatabase(db);
  app = createApp(db, { rateLimit: false, demoTools: true, fetchImpl: fakeFetch });
});

const login = async (email) => {
  const res = await request(app).post('/api/auth/login').send({ email, password: 'password123' });
  expect(res.status).toBe(200);
  return { Authorization: `Bearer ${res.body.token}` };
};

describe('authentication', () => {
  it('rejects wrong passwords and unknown emails with the same message', async () => {
    const a = await request(app).post('/api/auth/login').send({ email: 'aarav@campus.edu', password: 'wrong-password' });
    const b = await request(app).post('/api/auth/login').send({ email: 'ghost@campus.edu', password: 'whatever123' });
    expect(a.status).toBe(401);
    expect(b.status).toBe(401);
    expect(a.body.error).toBe(b.body.error);
  });

  it('registers a new user, stores a hash (never the password) and returns a token', async () => {
    const res = await request(app).post('/api/auth/register').send({ name: 'New Student', email: 'new@campus.edu', password: 'supersecret1', department: 'Physics' });
    expect(res.status).toBe(201);
    expect(res.body.token).toBeTruthy();
    const row = db.prepare('SELECT password_hash FROM users WHERE email = ?').get('new@campus.edu');
    expect(row.password_hash).not.toBe('supersecret1');
    expect(row.password_hash.startsWith('$2')).toBe(true);
  });

  it('blocks duplicate emails and weak passwords', async () => {
    const dup = await request(app).post('/api/auth/register').send({ name: 'Dup', email: 'AARAV@campus.edu', password: 'supersecret1', department: 'CS' });
    expect(dup.status).toBe(409);
    const weak = await request(app).post('/api/auth/register').send({ name: 'Weak', email: 'w@campus.edu', password: '123', department: 'CS' });
    expect(weak.status).toBe(400);
  });

  it('protects write endpoints and rejects forged tokens', async () => {
    expect((await request(app).post('/api/books').send({})).status).toBe(401);
    expect((await request(app).get('/api/requests/mine')).status).toBe(401);
    const forged = await request(app).get('/api/auth/me').set('Authorization', 'Bearer not.a.token');
    expect(forged.status).toBe(401);
  });

  it('sends security headers and hides x-powered-by', async () => {
    const res = await request(app).get('/api/health');
    expect(res.headers['x-powered-by']).toBeUndefined();
    expect(res.headers['x-content-type-options']).toBe('nosniff');
  });
});

describe('books', () => {
  it('lists the 35 seeded books publicly', async () => {
    const res = await request(app).get('/api/books');
    expect(res.status).toBe(200);
    expect(res.body).toHaveLength(35);
  });

  it('validates new listings and normalises the course code', async () => {
    const h = await login('meera@campus.edu');
    const bad = await request(app).post('/api/books').set(h).send({ title: '' });
    expect(bad.status).toBe(400);
    expect(bad.body.errors.title).toBeTruthy();
    const ok = await request(app).post('/api/books').set(h)
      .send({ title: 'Test Book', author: 'Me', edition: '1st', courseCode: 'cs 999', department: 'CS', condition: 'Good' });
    expect(ok.status).toBe(201);
    expect(ok.body.courseCode).toBe('CS999');
    expect(ok.body.ownerId).toBeTruthy();
  });

  it('only the owner can edit or delete a book', async () => {
    const meera = await login('meera@campus.edu');
    expect((await request(app).patch('/api/books/1').set(meera).send({ available: false })).status).toBe(403);
    expect((await request(app).delete('/api/books/1').set(meera)).status).toBe(403);
  });
});

describe('the demo flow from the brief', () => {
  it('list -> request -> approve -> countdown -> return -> rate', async () => {
    const aarav = await login('aarav@campus.edu');
    const meera = await login('meera@campus.edu');

    const reqRes = await request(app).post('/api/books/1/request').set(meera).send({ message: 'Library steps?' });
    expect(reqRes.status).toBe(201);
    const id = reqRes.body.id;
    expect((await request(app).get('/api/books/1')).body.status).toBe('reserved');

    // second student cannot grab the same copy
    const kabir = await login('kabir@campus.edu');
    expect((await request(app).post('/api/books/1/request').set(kabir)).status).toBe(409);

    // borrower cannot approve their own request
    expect((await request(app).post(`/api/requests/${id}/approve`).set(meera)).status).toBe(403);

    const approved = await request(app).post(`/api/requests/${id}/approve`).set(aarav);
    expect(approved.status).toBe(200);
    expect(approved.body.dueDate).toBeGreaterThan(Date.now());
    expect((await request(app).get('/api/books/1')).body.status).toBe('borrowed');

    const mine = await request(app).get('/api/requests/mine').set(meera);
    expect(mine.body.borrowing[0].status).toBe('approved');
    expect(mine.body.borrowing[0].lender.email).toBe('aarav@campus.edu');

    expect((await request(app).post(`/api/requests/${id}/return`).set(meera)).status).toBe(200);
    expect((await request(app).get('/api/books/1')).body.status).toBe('available');

    const rate = await request(app).post(`/api/requests/${id}/review`).set(meera).send({ rating: 5, comment: 'Smooth handoff' });
    expect(rate.status).toBe(200);
    expect((await request(app).get('/api/books/1')).body.owner.rating).toBe(5);
  });

  it('does not leak borrower emails or notes on the public book page', async () => {
    const meera = await login('meera@campus.edu');
    await request(app).post('/api/books/1/request').set(meera).send({ message: 'secret note' });
    const res = await request(app).get('/api/books/1');
    expect(JSON.stringify(res.body)).not.toContain('meera@campus.edu');
    expect(JSON.stringify(res.body)).not.toContain('secret note');
    expect(res.body.activeRequest.status).toBe('pending');
  });

  it('demo shift endpoint is hidden when demo tools are off', async () => {
    const prod = createApp(db, { rateLimit: false, demoTools: false });
    const aarav = await login('aarav@campus.edu');
    expect((await request(prod).post('/api/requests/1/shift').set(aarav).send({ days: -1 })).status).toBe(404);
  });
});

describe('Open Library ISBN lookup', () => {
  it('returns metadata for auto-fill', async () => {
    const h = await login('aarav@campus.edu');
    const res = await request(app).get('/api/isbn/978-1-119-80036-1').set(h);
    expect(res.status).toBe(200);
    expect(res.body.title).toBe('Operating System Concepts');
    expect(res.body.author).toBe('Abraham Silberschatz');
  });
  it('validates the ISBN and degrades gracefully when Open Library is down', async () => {
    const h = await login('aarav@campus.edu');
    expect((await request(app).get('/api/isbn/12').set(h)).status).toBe(400);
    const down = createApp(db, { rateLimit: false, fetchImpl: async () => { throw new Error('offline'); } });
    expect((await request(down).get('/api/isbn/9780262046305').set(h)).status).toBe(502);
  });
});

describe('wishlist', () => {
  it('lets a user watch a course and rejects bad codes', async () => {
    const h = await login('meera@campus.edu');
    expect((await request(app).post('/api/wishlist').set(h).send({ courseCode: 'cs 555' })).body.courseCode).toBe('CS555');
    expect((await request(app).post('/api/wishlist').set(h).send({ courseCode: '??' })).status).toBe(400);
    expect((await request(app).get('/api/wishlist').set(h)).body).toHaveLength(1);
  });
});
