import { describe, expect, it } from 'vitest';
import { isValidIsbn, normalizeCourseCode, validateBook, validateRegister, validateReview } from '../src/validators.js';

const good = { title: 'OS Concepts', author: 'Galvin', edition: '10th', courseCode: 'cs 301', department: 'CS', condition: 'Good', isbn: '978-1-119-80036-1' };

describe('validateBook', () => {
  it('accepts a valid book and normalises course code and ISBN', () => {
    const { value, errors } = validateBook(good);
    expect(errors).toEqual({});
    expect(value.courseCode).toBe('CS301');
    expect(value.isbn).toBe('9781119800361');
  });
  it('flags every bad field', () => {
    const { errors } = validateBook({ title: '', author: '', edition: '', courseCode: 'nope', department: '', condition: 'Mint', isbn: '123' });
    expect(Object.keys(errors).sort()).toEqual(['author', 'condition', 'courseCode', 'department', 'edition', 'isbn', 'title']);
  });
  it('ISBN is optional', () => {
    expect(validateBook({ ...good, isbn: '' }).errors).toEqual({});
  });
  it('does not crash on non-string input', () => {
    expect(Object.keys(validateBook({ title: 5, author: {}, courseCode: [] }).errors).length).toBeGreaterThan(3);
  });
});

describe('helpers', () => {
  it('normalizeCourseCode', () => expect(normalizeCourseCode(' cs-201 ')).toBe('CS201'));
  it('isValidIsbn', () => {
    expect(isValidIsbn('9781119800361')).toBe(true);
    expect(isValidIsbn('080442957X')).toBe(true);
    expect(isValidIsbn('12345')).toBe(false);
  });
});

describe('validateRegister', () => {
  it('requires a strong enough password and valid email', () => {
    const { errors } = validateRegister({ name: 'A', email: 'bad', password: 'short', department: '' });
    expect(Object.keys(errors).sort()).toEqual(['department', 'email', 'name', 'password']);
  });
  it('lower-cases the email', () => {
    expect(validateRegister({ name: 'Ann Lee', email: 'ANN@Campus.EDU', password: 'longenough1', department: 'Physics' }).value.email).toBe('ann@campus.edu');
  });
});

describe('validateReview', () => {
  it('accepts 1-5 integers only', () => {
    expect(validateReview({ rating: 5 }).errors).toEqual({});
    expect(Object.keys(validateReview({ rating: 6 }).errors)).toEqual(['rating']);
    expect(Object.keys(validateReview({ rating: 2.5 }).errors)).toEqual(['rating']);
  });
});
