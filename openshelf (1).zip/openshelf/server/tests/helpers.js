import { createDb } from '../src/db.js';

export const makeDb = () => createDb(':memory:');

export function addUser(db, name, email = `${name.toLowerCase()}@campus.edu`) {
  const info = db
    .prepare('INSERT INTO users (name, email, password_hash, department, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(name, email, 'x', 'Computer Science', Date.now());
  return { id: Number(info.lastInsertRowid), name, email };
}

export function addBook(db, ownerId, overrides = {}) {
  const b = { title: 'Operating System Concepts', author: 'Galvin', edition: '10th', course_code: 'CS301',
    department: 'Computer Science', isbn: '9781119800361', condition: 'Good', ...overrides };
  const info = db
    .prepare('INSERT INTO books (title, author, edition, course_code, department, isbn, condition, owner_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .run(b.title, b.author, b.edition, b.course_code, b.department, b.isbn, b.condition, ownerId, Date.now());
  return Number(info.lastInsertRowid);
}

// Runs fn and returns the thrown HttpError status (or null if nothing threw).
export function errorStatus(fn) {
  try { fn(); return null; } catch (e) { return e.status ?? 'unexpected'; }
}
