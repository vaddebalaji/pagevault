import Database from 'better-sqlite3';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  department    TEXT NOT NULL DEFAULT '',
  created_at    INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS books (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  title       TEXT NOT NULL,
  author      TEXT NOT NULL,
  edition     TEXT NOT NULL,
  course_code TEXT NOT NULL,
  department  TEXT NOT NULL,
  isbn        TEXT NOT NULL DEFAULT '',
  condition   TEXT NOT NULL,
  owner_id    INTEGER NOT NULL REFERENCES users(id),
  status      TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available','reserved','borrowed')),
  created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_books_course ON books(course_code);
CREATE INDEX IF NOT EXISTS idx_books_owner ON books(owner_id);
CREATE TABLE IF NOT EXISTS requests (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  book_id     INTEGER NOT NULL REFERENCES books(id),
  lender_id   INTEGER NOT NULL REFERENCES users(id),
  borrower_id INTEGER NOT NULL REFERENCES users(id),
  status      TEXT NOT NULL CHECK (status IN ('pending','approved','returned','rejected')),
  message     TEXT NOT NULL DEFAULT '',
  requested_at INTEGER NOT NULL,
  approved_at INTEGER,
  due_date    INTEGER,
  returned_at INTEGER,
  on_time     INTEGER
);
-- DB-level guard: a book can have at most one open (pending/approved) request.
CREATE UNIQUE INDEX IF NOT EXISTS one_open_request_per_book
  ON requests(book_id) WHERE status IN ('pending','approved');
CREATE INDEX IF NOT EXISTS idx_requests_borrower ON requests(borrower_id);
CREATE INDEX IF NOT EXISTS idx_requests_lender ON requests(lender_id);
CREATE TABLE IF NOT EXISTS notifications (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id),
  message    TEXT NOT NULL,
  type       TEXT NOT NULL DEFAULT 'info',
  read       INTEGER NOT NULL DEFAULT 0,
  dedupe_key TEXT UNIQUE,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reviews (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id  INTEGER NOT NULL REFERENCES requests(id),
  reviewer_id INTEGER NOT NULL REFERENCES users(id),
  reviewee_id INTEGER NOT NULL REFERENCES users(id),
  rating      INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment     TEXT NOT NULL DEFAULT '',
  created_at  INTEGER NOT NULL,
  UNIQUE (request_id, reviewer_id)
);
CREATE TABLE IF NOT EXISTS wishlist (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id),
  course_code TEXT NOT NULL,
  UNIQUE (user_id, course_code)
);
`;

export function createDb(file = ':memory:') {
  const db = new Database(file);
  db.exec('PRAGMA foreign_keys = ON;');
  if (file !== ':memory:') db.exec('PRAGMA journal_mode = WAL;');
  db.exec(SCHEMA);
  return db;
}

// Runs fn inside an IMMEDIATE transaction: all-or-nothing, and writers are serialised across processes.
export function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}
