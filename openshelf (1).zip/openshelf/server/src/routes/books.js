import { Router } from 'express';
import { authenticate } from '../auth.js';
import { HttpError } from '../errors.js';
import { assertValid, validateBook } from '../validators.js';
import { getBook, getRequest, listBooks, userTrust } from '../queries.js';
import { notifyWishlist, requestBook } from '../services/exchange.js';

export default function booksRouter(db) {
  const r = Router();
  const optional = authenticate(db, { required: false });
  const required = authenticate(db);
  const id = (req) => {
    const n = Number(req.params.id);
    if (!Number.isInteger(n) || n < 1) throw new HttpError(404, 'Book not found');
    return n;
  };

  r.get('/', (_req, res) => res.json(listBooks(db)));

  r.get('/:id', optional, (req, res) => {
    const book = getBook(db, id(req));
    if (!book) throw new HttpError(404, 'Book not found');
    const open = db.prepare("SELECT id FROM requests WHERE book_id = ? AND status IN ('pending','approved')").get(book.id);
    // Public view: only what a visitor needs (never other people's emails or request notes).
    let activeRequest = null;
    if (open) {
      const full = getRequest(db, open.id, req.user?.id ?? 0);
      activeRequest = { id: full.id, status: full.status, dueDate: full.dueDate, isMine: req.user?.id === full.borrowerId };
    }
    res.json({ ...book, owner: { ...book.owner, ...userTrust(db, book.ownerId) }, activeRequest });
  });

  r.post('/', required, (req, res) => {
    const v = assertValid(validateBook(req.body));
    const info = db.prepare(
      'INSERT INTO books (title, author, edition, course_code, department, isbn, condition, owner_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(v.title, v.author, v.edition, v.courseCode, v.department, v.isbn, v.condition, req.user.id, Date.now());
    const bookId = Number(info.lastInsertRowid);
    notifyWishlist(db, db.prepare('SELECT * FROM books WHERE id = ?').get(bookId));
    res.status(201).json(getBook(db, bookId));
  });

  // Owner toggles available <-> reserved while there is no open exchange.
  r.patch('/:id', required, (req, res) => {
    const book = getBook(db, id(req));
    if (!book) throw new HttpError(404, 'Book not found');
    if (book.ownerId !== req.user.id) throw new HttpError(403, 'Only the owner can change this book');
    if (typeof req.body?.available !== 'boolean') throw new HttpError(400, 'available must be true or false');
    const next = req.body.available ? 'available' : 'reserved';
    const upd = db.prepare(
      "UPDATE books SET status = ? WHERE id = ? AND status IN ('available','reserved') AND NOT EXISTS (SELECT 1 FROM requests WHERE book_id = ? AND status IN ('pending','approved'))"
    ).run(next, book.id, book.id);
    if (Number(upd.changes) !== 1) throw new HttpError(409, 'Book has an active exchange');
    if (next === 'available') notifyWishlist(db, db.prepare('SELECT * FROM books WHERE id = ?').get(book.id));
    res.json(getBook(db, book.id));
  });

  r.delete('/:id', required, (req, res) => {
    const book = getBook(db, id(req));
    if (!book) throw new HttpError(404, 'Book not found');
    if (book.ownerId !== req.user.id) throw new HttpError(403, 'Only the owner can delete this book');
    if (db.prepare('SELECT 1 FROM requests WHERE book_id = ?').get(book.id)) {
      throw new HttpError(409, 'This book has exchange history. Mark it unavailable instead.');
    }
    db.prepare('DELETE FROM books WHERE id = ?').run(book.id);
    res.status(204).end();
  });

  r.post('/:id/request', required, (req, res) => {
    const requestId = requestBook(db, req.user, id(req), req.body?.message);
    res.status(201).json(getRequest(db, requestId, req.user.id));
  });

  return r;
}
