import { Router } from 'express';
import { authenticate } from '../auth.js';
import { asyncHandler, HttpError } from '../errors.js';
import { assertValid, isValidIsbn, normalizeIsbn, validateCourseCode } from '../validators.js';
import { ensureReminders } from '../services/exchange.js';
import { lookupIsbn } from '../services/openLibrary.js';

export default function miscRouter(db, { fetchImpl = fetch } = {}) {
  const r = Router();
  const auth = authenticate(db);

  r.get('/notifications', auth, (req, res) => {
    ensureReminders(db);
    res.json(db.prepare(
      'SELECT id, message, type, read, created_at AS createdAt FROM notifications WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 50'
    ).all(req.user.id).map((n) => ({ ...n, read: !!n.read })));
  });

  r.post('/notifications/read', auth, (req, res) => {
    db.prepare('UPDATE notifications SET read = 1 WHERE user_id = ?').run(req.user.id);
    res.json({ ok: true });
  });

  r.get('/wishlist', auth, (req, res) => {
    res.json(db.prepare('SELECT id, course_code AS courseCode FROM wishlist WHERE user_id = ? ORDER BY course_code').all(req.user.id));
  });

  r.post('/wishlist', auth, (req, res) => {
    const { courseCode } = assertValid(validateCourseCode(req.body));
    db.prepare('INSERT OR IGNORE INTO wishlist (user_id, course_code) VALUES (?, ?)').run(req.user.id, courseCode);
    res.status(201).json(db.prepare('SELECT id, course_code AS courseCode FROM wishlist WHERE user_id = ? AND course_code = ?').get(req.user.id, courseCode));
  });

  r.delete('/wishlist/:id', auth, (req, res) => {
    db.prepare('DELETE FROM wishlist WHERE id = ? AND user_id = ?').run(Number(req.params.id), req.user.id);
    res.status(204).end();
  });

  // Open Library metadata for ISBN auto-fill (used by the form and the barcode scanner).
  r.get('/isbn/:isbn', auth, asyncHandler(async (req, res) => {
    const isbn = normalizeIsbn(req.params.isbn);
    if (!isValidIsbn(isbn)) throw new HttpError(400, 'ISBN must be 10 or 13 digits');
    const info = await lookupIsbn(isbn, fetchImpl);
    if (!info) throw new HttpError(404, 'No book found for that ISBN');
    res.json(info);
  }));

  return r;
}
