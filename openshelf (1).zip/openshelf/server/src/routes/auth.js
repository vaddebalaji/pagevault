import { Router } from 'express';
import bcrypt from 'bcryptjs';
import rateLimit from 'express-rate-limit';
import { BCRYPT_ROUNDS } from '../config.js';
import { authenticate, signToken } from '../auth.js';
import { asyncHandler, HttpError } from '../errors.js';
import { assertValid, validateRegister } from '../validators.js';

const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, department: u.department });
// Compared against when the email is unknown, so response time doesn't reveal which emails exist.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', BCRYPT_ROUNDS);

export default function authRouter(db, { rateLimit: limit = true } = {}) {
  const r = Router();
  if (limit) r.use(rateLimit({ windowMs: 15 * 60_000, limit: 30, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many attempts. Try again later.' } }));

  r.post('/register', asyncHandler(async (req, res) => {
    const v = assertValid(validateRegister(req.body));
    if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(v.email)) {
      throw new HttpError(409, 'That email is already registered', { email: 'Already registered' });
    }
    const hash = await bcrypt.hash(v.password, BCRYPT_ROUNDS);
    const info = db.prepare('INSERT INTO users (name, email, password_hash, department, created_at) VALUES (?, ?, ?, ?, ?)')
      .run(v.name, v.email, hash, v.department, Date.now());
    const user = db.prepare('SELECT id, name, email, department FROM users WHERE id = ?').get(Number(info.lastInsertRowid));
    res.status(201).json({ token: signToken(user), user: publicUser(user) });
  }));

  r.post('/login', asyncHandler(async (req, res) => {
    const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    const ok = await bcrypt.compare(password, row ? row.password_hash : DUMMY_HASH);
    if (!row || !ok) throw new HttpError(401, 'Incorrect email or password');
    res.json({ token: signToken(row), user: publicUser(row) });
  }));

  r.get('/me', authenticate(db), (req, res) => res.json({ user: publicUser(req.user) }));
  return r;
}
