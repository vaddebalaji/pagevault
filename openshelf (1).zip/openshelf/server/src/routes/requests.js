import { Router } from 'express';
import { authenticate } from '../auth.js';
import { HttpError } from '../errors.js';
import { assertValid, validateReview } from '../validators.js';
import { getRequest, listRequestsFor } from '../queries.js';
import {
  approveRequest, ensureReminders, rejectRequest, returnRequest, reviewExchange, shiftDueDate,
} from '../services/exchange.js';

export default function requestsRouter(db, { demoTools = false } = {}) {
  const r = Router();
  r.use(authenticate(db));

  const rid = (req) => {
    const n = Number(req.params.id);
    if (!Number.isInteger(n) || n < 1) throw new HttpError(404, 'Request not found');
    return n;
  };
  const send = (res, req, id) => res.json(getRequest(db, id, req.user.id));

  r.get('/mine', (req, res) => {
    ensureReminders(db);
    res.json(listRequestsFor(db, req.user.id));
  });
  r.post('/:id/approve', (req, res) => send(res, req, approveRequest(db, req.user, rid(req))));
  r.post('/:id/reject', (req, res) => send(res, req, rejectRequest(db, req.user, rid(req))));
  r.post('/:id/return', (req, res) => send(res, req, returnRequest(db, req.user, rid(req))));
  r.post('/:id/review', (req, res) => {
    const id = rid(req);
    reviewExchange(db, req.user, id, assertValid(validateReview(req.body)));
    send(res, req, id);
  });
  r.post('/:id/shift', (req, res) => {
    if (!demoTools) throw new HttpError(404, 'Not found');
    send(res, req, shiftDueDate(db, req.user, rid(req), Number(req.body?.days)));
  });
  return r;
}
