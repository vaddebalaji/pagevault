import jwt from 'jsonwebtoken';
import { JWT_EXPIRES, JWT_SECRET } from './config.js';
import { HttpError } from './errors.js';

export const signToken = (user) => jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: JWT_EXPIRES, algorithm: 'HS256' });

// required=true -> 401 when missing/invalid. required=false -> req.user is null for anonymous visitors.
export const authenticate = (db, { required = true } = {}) => (req, _res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return required ? next(new HttpError(401, 'Please log in first.')) : ((req.user = null), next());
  try {
    const { sub } = jwt.verify(token, JWT_SECRET, { algorithms: ['HS256'] });
    const user = db.prepare('SELECT id, name, email, department FROM users WHERE id = ?').get(sub);
    if (!user) throw new Error('unknown user');
    req.user = user;
    next();
  } catch {
    next(new HttpError(401, 'Session expired. Please log in again.'));
  }
};
