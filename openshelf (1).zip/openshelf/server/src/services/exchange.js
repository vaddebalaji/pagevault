// Business logic for the exchange workflow. Pure functions over a db handle so they are easy to unit test.
import { DAY, LOAN_DAYS, MAX_ACTIVE_BORROWS, SOON_DAYS } from '../config.js';
import { tx } from '../db.js';
import { HttpError } from '../errors.js';

const now = () => Date.now();
const changed = (info) => Number(info.changes) === 1;

export function notify(db, userId, message, type = 'info', dedupeKey = null) {
  db.prepare('INSERT OR IGNORE INTO notifications (user_id, message, type, dedupe_key, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(userId, message, type, dedupeKey, now());
}

// Wishlist: alert everyone (except the owner) watching this course code that a copy is available.
export function notifyWishlist(db, book) {
  const watchers = db.prepare('SELECT user_id FROM wishlist WHERE course_code = ? AND user_id <> ?').all(book.course_code, book.owner_id);
  for (const w of watchers) {
    notify(db, w.user_id, `A ${book.course_code} book you're watching is available: "${book.title}".`, 'wishlist');
  }
}

const rawBook = (db, id) => db.prepare('SELECT * FROM books WHERE id = ?').get(id);
function mustRequest(db, id) {
  const r = db.prepare('SELECT * FROM requests WHERE id = ?').get(id);
  if (!r) throw new HttpError(404, 'Request not found');
  return r;
}

export function requestBook(db, user, bookId, message = '') {
  return tx(db, () => {
    const book = rawBook(db, bookId);
    if (!book) throw new HttpError(404, 'Book not found');
    if (book.owner_id === user.id) throw new HttpError(400, "You can't borrow your own book");

    const { n } = db.prepare("SELECT COUNT(*) AS n FROM requests WHERE borrower_id = ? AND status IN ('pending','approved')").get(user.id);
    if (n >= MAX_ACTIVE_BORROWS) {
      throw new HttpError(409, `You can have at most ${MAX_ACTIVE_BORROWS} active requests or loans at a time`);
    }

    // Atomic check-and-flip: only one caller can move the book from 'available' to 'reserved'.
    const flip = db.prepare("UPDATE books SET status = 'reserved' WHERE id = ? AND status = 'available'").run(bookId);
    if (!changed(flip)) throw new HttpError(409, 'This book is no longer available');

    const info = db
      .prepare('INSERT INTO requests (book_id, lender_id, borrower_id, status, message, requested_at) VALUES (?, ?, ?, ?, ?, ?)')
      .run(bookId, book.owner_id, user.id, 'pending', String(message || '').slice(0, 300), now());
    notify(db, book.owner_id, `${user.name} requested to borrow "${book.title}".`, 'request');
    return Number(info.lastInsertRowid);
  });
}

export function approveRequest(db, user, requestId) {
  return tx(db, () => {
    const r = mustRequest(db, requestId);
    if (r.lender_id !== user.id) throw new HttpError(403, 'Only the lender can approve');
    const t = now();
    const upd = db
      .prepare("UPDATE requests SET status = 'approved', approved_at = ?, due_date = ? WHERE id = ? AND status = 'pending'")
      .run(t, t + LOAN_DAYS * DAY, requestId);
    if (!changed(upd)) throw new HttpError(409, `Request is already ${r.status}`);
    db.prepare("UPDATE books SET status = 'borrowed' WHERE id = ?").run(r.book_id);
    notify(db, r.borrower_id, `Approved! Return "${rawBook(db, r.book_id).title}" within ${LOAN_DAYS} days.`, 'approved');
    return requestId;
  });
}

export function rejectRequest(db, user, requestId) {
  return tx(db, () => {
    const r = mustRequest(db, requestId);
    if (r.lender_id !== user.id) throw new HttpError(403, 'Only the lender can reject');
    const upd = db.prepare("UPDATE requests SET status = 'rejected' WHERE id = ? AND status = 'pending'").run(requestId);
    if (!changed(upd)) throw new HttpError(409, `Request is already ${r.status}`);
    db.prepare("UPDATE books SET status = 'available' WHERE id = ?").run(r.book_id);
    const book = rawBook(db, r.book_id);
    notify(db, r.borrower_id, `Your request for "${book.title}" was declined.`, 'rejected');
    notifyWishlist(db, book);
    return requestId;
  });
}

export function returnRequest(db, user, requestId) {
  return tx(db, () => {
    const r = mustRequest(db, requestId);
    if (![r.lender_id, r.borrower_id].includes(user.id)) throw new HttpError(403, 'Not your exchange');
    const t = now();
    const upd = db
      .prepare("UPDATE requests SET status = 'returned', returned_at = ?, on_time = (? <= due_date) WHERE id = ? AND status = 'approved'")
      .run(t, t, requestId);
    if (!changed(upd)) throw new HttpError(409, 'Only borrowed books can be returned');
    db.prepare("UPDATE books SET status = 'available' WHERE id = ?").run(r.book_id);
    const book = rawBook(db, r.book_id);
    const other = user.id === r.lender_id ? r.borrower_id : r.lender_id;
    notify(db, other, `"${book.title}" was marked as returned.`, 'returned');
    notifyWishlist(db, book);
    return requestId;
  });
}

// Demo helper (disabled in production by the router): move the due date to simulate "soon"/"overdue".
export function shiftDueDate(db, user, requestId, days) {
  return tx(db, () => {
    const r = mustRequest(db, requestId);
    if (![r.lender_id, r.borrower_id].includes(user.id)) throw new HttpError(403, 'Not your exchange');
    if (r.status !== 'approved') throw new HttpError(409, 'Only active loans have a due date');
    if (!Number.isFinite(days) || Math.abs(days) > 60) throw new HttpError(400, 'days must be a number between -60 and 60');
    db.prepare('UPDATE requests SET due_date = ? WHERE id = ?').run(now() + days * DAY, requestId);
    // allow reminders to fire again for the new due date
    db.prepare('DELETE FROM notifications WHERE dedupe_key IN (?, ?, ?)')
      .run(`soon:${requestId}`, `overdue:${requestId}`, `overdue-lender:${requestId}`);
    return requestId;
  });
}

// Peer trust rating: either party may rate the other once per returned exchange.
export function reviewExchange(db, user, requestId, { rating, comment }) {
  return tx(db, () => {
    const r = mustRequest(db, requestId);
    if (![r.lender_id, r.borrower_id].includes(user.id)) throw new HttpError(403, 'Not your exchange');
    if (r.status !== 'returned') throw new HttpError(409, 'You can rate an exchange once the book is returned');
    const reviewee = user.id === r.lender_id ? r.borrower_id : r.lender_id;
    try {
      db.prepare('INSERT INTO reviews (request_id, reviewer_id, reviewee_id, rating, comment, created_at) VALUES (?, ?, ?, ?, ?, ?)')
        .run(requestId, user.id, reviewee, rating, comment, now());
    } catch (e) {
      if (/UNIQUE/i.test(String(e.message))) throw new HttpError(409, 'You already rated this exchange');
      throw e;
    }
    return requestId;
  });
}

// Server-side reminders, generated lazily (no cron). Dedupe keys make this idempotent.
export function ensureReminders(db, at = now()) {
  const loans = db
    .prepare("SELECT r.id, r.due_date, r.borrower_id, r.lender_id, b.title FROM requests r JOIN books b ON b.id = r.book_id WHERE r.status = 'approved'")
    .all();
  for (const l of loans) {
    if (l.due_date < at) {
      notify(db, l.borrower_id, `"${l.title}" is overdue. Please return it.`, 'overdue', `overdue:${l.id}`);
      notify(db, l.lender_id, `"${l.title}" is overdue.`, 'overdue', `overdue-lender:${l.id}`);
    } else if (l.due_date - at <= SOON_DAYS * DAY) {
      notify(db, l.borrower_id, `"${l.title}" is due within ${SOON_DAYS} days.`, 'reminder', `soon:${l.id}`);
    }
  }
}
