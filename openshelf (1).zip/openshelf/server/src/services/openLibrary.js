// Open Library lookup for ISBN auto-fill. fetch is injectable so tests never hit the network.
import { HttpError } from '../errors.js';

const cache = new Map();

export async function lookupIsbn(isbn, fetchImpl = fetch) {
  if (cache.has(isbn)) return cache.get(isbn);
  const url = `https://openlibrary.org/api/books?bibkeys=ISBN:${encodeURIComponent(isbn)}&format=json&jscmd=data`;
  let data;
  try {
    const res = await fetchImpl(url, { signal: AbortSignal.timeout(5000), headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error(`status ${res.status}`);
    data = await res.json();
  } catch {
    throw new HttpError(502, 'Open Library is unavailable right now. You can enter the details manually.');
  }
  const entry = data[`ISBN:${isbn}`];
  if (!entry) return null;
  const result = {
    isbn,
    title: [entry.title, entry.subtitle].filter(Boolean).join(': '),
    author: (entry.authors || []).map((a) => a.name).join(', '),
    publishDate: entry.publish_date || '',
    coverUrl: entry.cover?.medium || null,
  };
  cache.set(isbn, result);
  return result;
}
