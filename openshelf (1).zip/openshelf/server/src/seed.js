import bcrypt from 'bcryptjs';
import { BCRYPT_ROUNDS } from './config.js';
import { tx } from './db.js';

// [title, author, edition, courseCode, department, isbn, condition]
export const BOOKS = [
  ['Operating System Concepts', 'Silberschatz, Galvin, Gagne', '10th', 'CS301', 'Computer Science', '9781119800361', 'Good'],
  ['Introduction to Algorithms', 'Cormen, Leiserson, Rivest, Stein', '4th', 'CS201', 'Computer Science', '9780262046305', 'Like New'],
  ['Computer Networking: A Top-Down Approach', 'Kurose, Ross', '8th', 'CS304', 'Computer Science', '9780135928615', 'Good'],
  ['Database System Concepts', 'Silberschatz, Korth, Sudarshan', '7th', 'CS302', 'Computer Science', '9780078022159', 'Fair'],
  ['Artificial Intelligence: A Modern Approach', 'Russell, Norvig', '4th', 'CS401', 'Computer Science', '9780134610993', 'Good'],
  ['Computer Organization and Design', 'Patterson, Hennessy', '5th', 'CS202', 'Computer Science', '9780124077263', 'Good'],
  ['Compilers: Principles, Techniques, and Tools', 'Aho, Lam, Sethi, Ullman', '2nd', 'CS402', 'Computer Science', '9780321486813', 'Fair'],
  ['Data Structures and Algorithm Analysis in C++', 'Weiss', '4th', 'CS102', 'Computer Science', '9780132847377', 'Like New'],
  ['Discrete Mathematics and Its Applications', 'Rosen', '8th', 'MA202', 'Mathematics', '9781259676512', 'Good'],
  ['Calculus: Early Transcendentals', 'Stewart', '9th', 'MA101', 'Mathematics', '9781337613927', 'Good'],
  ['Linear Algebra and Its Applications', 'Lay, Lay, McDonald', '5th', 'MA201', 'Mathematics', '9780321982384', 'Like New'],
  ['Advanced Engineering Mathematics', 'Kreyszig', '10th', 'MA301', 'Mathematics', '9780470458365', 'Fair'],
  ['Probability and Statistics for Engineers', 'Walpole, Myers', '9th', 'MA210', 'Mathematics', '9780321629111', 'Good'],
  ['Introduction to Linear Algebra', 'Strang', '5th', 'MA203', 'Mathematics', '9780980232776', 'Good'],
  ['University Physics', 'Young, Freedman', '15th', 'PH101', 'Physics', '9780135159552', 'Good'],
  ['Fundamentals of Physics', 'Halliday, Resnick, Walker', '11th', 'PH102', 'Physics', '9781119773511', 'Like New'],
  ['Introduction to Electrodynamics', 'Griffiths', '4th', 'PH301', 'Physics', '9781108420419', 'Good'],
  ['Introduction to Quantum Mechanics', 'Griffiths', '3rd', 'PH302', 'Physics', '9781107179868', 'Fair'],
  ['Chemistry: The Central Science', 'Brown, LeMay, Bursten', '14th', 'CH101', 'Chemistry', '9780134414232', 'Good'],
  ['Organic Chemistry', 'Clayden, Greeves, Warren', '2nd', 'CH201', 'Chemistry', '9780199270293', 'Good'],
  ['Physical Chemistry', 'Atkins, de Paula', '11th', 'CH301', 'Chemistry', '9780198769866', 'Fair'],
  ['Campbell Biology', 'Urry, Cain, Wasserman', '12th', 'BT101', 'Biotechnology', '9780135188743', 'Good'],
  ['Molecular Biology of the Cell', 'Alberts et al.', '6th', 'BT201', 'Biotechnology', '9780815344322', 'Good'],
  ['Lehninger Principles of Biochemistry', 'Nelson, Cox', '8th', 'BT202', 'Biotechnology', '9781319228002', 'Like New'],
  ['Engineering Mechanics: Statics', 'Hibbeler', '14th', 'ME101', 'Mechanical Engineering', '9780133915426', 'Good'],
  ['Thermodynamics: An Engineering Approach', 'Cengel, Boles', '9th', 'ME201', 'Mechanical Engineering', '9781260048667', 'Good'],
  ['Fluid Mechanics', 'White', '8th', 'ME301', 'Mechanical Engineering', '9780073398273', 'Fair'],
  ["Shigley's Mechanical Engineering Design", 'Budynas, Nisbett', '11th', 'ME302', 'Mechanical Engineering', '9780073398211', 'Good'],
  ['Microelectronic Circuits', 'Sedra, Smith', '8th', 'EE201', 'Electrical Engineering', '9780190853501', 'Good'],
  ['Signals and Systems', 'Oppenheim, Willsky', '2nd', 'EE202', 'Electrical Engineering', '9780138147570', 'Good'],
  ['Digital Design', 'Mano, Ciletti', '6th', 'EE203', 'Electrical Engineering', '9780134549897', 'Like New'],
  ['Engineering Circuit Analysis', 'Hayt, Kemmerly, Durbin', '9th', 'EE101', 'Electrical Engineering', '9780073529578', 'Fair'],
  ['Structural Analysis', 'Hibbeler', '10th', 'CE201', 'Civil Engineering', '9780134610672', 'Good'],
  ['Mechanics of Materials', 'Beer, Johnston, DeWolf', '8th', 'CE101', 'Civil Engineering', '9781259665264', 'Good'],
  ['Principles of Geotechnical Engineering', 'Das, Sivakugan', '9th', 'CE301', 'Civil Engineering', '9781305970939', 'Fair'],
];

export const DEMO_PASSWORD = 'password123';
export const DEMO_USERS = [
  ['Aarav (Student A)', 'aarav@campus.edu', 'Computer Science'],
  ['Meera (Student B)', 'meera@campus.edu', 'Computer Science'],
  ['Kabir', 'kabir@campus.edu', 'Mechanical Engineering'],
  ['Sana', 'sana@campus.edu', 'Physics'],
];

export async function seedDatabase(db) {
  const hash = await bcrypt.hash(DEMO_PASSWORD, BCRYPT_ROUNDS);
  const t = Date.now();
  tx(db, () => {
    const addUser = db.prepare('INSERT INTO users (name, email, password_hash, department, created_at) VALUES (?, ?, ?, ?, ?)');
    DEMO_USERS.forEach(([name, email, dept]) => addUser.run(name, email, hash, dept, t));
    const addBook = db.prepare(
      'INSERT INTO books (title, author, edition, course_code, department, isbn, condition, owner_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    BOOKS.forEach(([title, author, edition, code, dept, isbn, cond], i) => {
      const ownerId = i === 0 ? 1 : [3, 4, 1, 2][i % 4]; // CS301 belongs to Aarav (demo flow)
      addBook.run(title, author, edition, code, dept, isbn, cond, ownerId, t - i * 3_600_000);
    });
  });
}
