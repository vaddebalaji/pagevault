// Single source of truth for business rules. The client reads these via GET /api/config.
export const DAY = 86_400_000;
export const LOAN_DAYS = 7;
export const SOON_DAYS = 2;
export const MAX_ACTIVE_BORROWS = 3;
export const CONDITIONS = ['Like New', 'Good', 'Fair', 'Poor'];

export const IS_PROD = process.env.NODE_ENV === 'production';
export const BCRYPT_ROUNDS = process.env.NODE_ENV === 'test' ? 4 : 10;
export const JWT_EXPIRES = '12h';

export const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-secret-do-not-use-in-production';
if (IS_PROD && !process.env.JWT_SECRET) {
  throw new Error('JWT_SECRET must be set in production');
}
