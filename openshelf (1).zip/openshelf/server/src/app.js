import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { IS_PROD, LOAN_DAYS, MAX_ACTIVE_BORROWS, SOON_DAYS } from './config.js';
import { errorHandler, notFound } from './errors.js';
import authRouter from './routes/auth.js';
import booksRouter from './routes/books.js';
import requestsRouter from './routes/requests.js';
import miscRouter from './routes/misc.js';

// opts: { rateLimit: boolean, demoTools: boolean, fetchImpl: typeof fetch }
export function createApp(db, opts = {}) {
  const demoTools = opts.demoTools ?? !IS_PROD;
  const app = express();
  app.disable('x-powered-by');
  app.use(helmet());
  app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
  app.use(express.json({ limit: '10kb' }));

  app.get('/api/health', (_req, res) => res.json({ ok: true }));
  app.get('/api/config', (_req, res) => res.json({ loanDays: LOAN_DAYS, soonDays: SOON_DAYS, maxActiveBorrows: MAX_ACTIVE_BORROWS, demoTools }));

  app.use('/api/auth', authRouter(db, opts));
  app.use('/api/books', booksRouter(db));
  app.use('/api/requests', requestsRouter(db, { demoTools }));
  app.use('/api', miscRouter(db, opts));

  app.use(notFound);
  app.use(errorHandler);
  return app;
}
