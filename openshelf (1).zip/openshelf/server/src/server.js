import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createApp } from './app.js';
import { createDb } from './db.js';
import { seedDatabase } from './seed.js';

const dataDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'data');
const file = process.env.DB_FILE || path.join(dataDir, 'openshelf.db');
fs.mkdirSync(path.dirname(file), { recursive: true });

const db = createDb(file);
if (db.prepare('SELECT COUNT(*) AS n FROM users').get().n === 0) {
  await seedDatabase(db);
  console.log('Seeded demo users and 35 textbooks (demo password: password123)');
}

const port = process.env.PORT || 3001;
createApp(db).listen(port, () => console.log(`OpenShelf API on http://localhost:${port}`));
