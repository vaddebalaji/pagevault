// Read helpers: SQL rows -> API shapes (camelCase, nested objects). No writes here.

const BOOK_SQL = `
  SELECT b.id, b.title, b.author, b.edition, b.course_code AS courseCode, b.department, b.isbn,
         b.condition, b.owner_id AS ownerId, b.status, b.created_at AS createdAt, u.name AS ownerName
  FROM books b JOIN users u ON u.id = b.owner_id`;

const toBook = ({ ownerName, ...b }) => ({ ...b, owner: { id: b.ownerId, name: ownerName } });

export const listBooks = (db) => db.prepare(`${BOOK_SQL} ORDER BY b.created_at DESC, b.id DESC`).all().map(toBook);

export function getBook(db, id) {
  const row = db.prepare(`${BOOK_SQL} WHERE b.id = ?`).get(id);
  return row ? toBook(row) : null;
}

export function userTrust(db, userId) {
  const { avg, n } = db.prepare('SELECT AVG(rating) AS avg, COUNT(*) AS n FROM reviews WHERE reviewee_id = ?').get(userId);
  return { rating: n ? Math.round(avg * 10) / 10 : null, ratingCount: n };
}

const REQUEST_SQL = `
  SELECT r.id, r.book_id AS bookId, r.lender_id AS lenderId, r.borrower_id AS borrowerId, r.status, r.message,
         r.requested_at AS requestedAt, r.approved_at AS approvedAt, r.due_date AS dueDate,
         r.returned_at AS returnedAt, r.on_time AS onTime,
         b.title AS bookTitle, b.author AS bookAuthor, b.course_code AS bookCourseCode, b.isbn AS bookIsbn,
         l.name AS lenderName, l.email AS lenderEmail, bo.name AS borrowerName, bo.email AS borrowerEmail,
         EXISTS(SELECT 1 FROM reviews v WHERE v.request_id = r.id AND v.reviewer_id = ?) AS reviewed
  FROM requests r
  JOIN books b ON b.id = r.book_id
  JOIN users l ON l.id = r.lender_id
  JOIN users bo ON bo.id = r.borrower_id`;

// Contact emails are only revealed to the two parties once a request is approved (handoff needs them).
function toRequest(row) {
  const reveal = row.status === 'approved' || row.status === 'returned';
  return {
    id: row.id, bookId: row.bookId, lenderId: row.lenderId, borrowerId: row.borrowerId,
    status: row.status, message: row.message, requestedAt: row.requestedAt, approvedAt: row.approvedAt,
    dueDate: row.dueDate, returnedAt: row.returnedAt,
    onTime: row.onTime === null ? null : !!row.onTime,
    reviewed: !!row.reviewed,
    book: { id: row.bookId, title: row.bookTitle, author: row.bookAuthor, courseCode: row.bookCourseCode, isbn: row.bookIsbn },
    lender: { id: row.lenderId, name: row.lenderName, email: reveal ? row.lenderEmail : null },
    borrower: { id: row.borrowerId, name: row.borrowerName, email: reveal ? row.borrowerEmail : null },
  };
}

export function getRequest(db, id, viewerId) {
  const row = db.prepare(`${REQUEST_SQL} WHERE r.id = ?`).get(viewerId, id);
  return row ? toRequest(row) : null;
}

export function listRequestsFor(db, userId) {
  const rows = db
    .prepare(`${REQUEST_SQL} WHERE r.lender_id = ? OR r.borrower_id = ? ORDER BY r.requested_at DESC, r.id DESC`)
    .all(userId, userId, userId);
  const all = rows.map(toRequest);
  return { lending: all.filter((r) => r.lenderId === userId), borrowing: all.filter((r) => r.borrowerId === userId) };
}
