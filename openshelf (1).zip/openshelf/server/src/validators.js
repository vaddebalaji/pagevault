import { CONDITIONS } from './config.js';
import { HttpError } from './errors.js';

const str = (v) => (typeof v === 'string' ? v.trim() : '');

export const normalizeCourseCode = (v) => str(v).replace(/[\s-]/g, '').toUpperCase();
export const normalizeIsbn = (v) => str(v).replace(/[\s-]/g, '').toUpperCase();
export const isValidIsbn = (v) => /^(\d{13}|\d{9}[\dX])$/.test(v);

export function assertValid({ value, errors }) {
  if (Object.keys(errors).length) throw new HttpError(400, 'Validation failed', errors);
  return value;
}

export function validateBook(input = {}) {
  const errors = {};
  const value = {
    title: str(input.title),
    author: str(input.author),
    edition: str(input.edition),
    courseCode: normalizeCourseCode(input.courseCode),
    department: str(input.department),
    isbn: normalizeIsbn(input.isbn),
    condition: input.condition,
  };
  if (!value.title) errors.title = 'Title is required';
  else if (value.title.length > 200) errors.title = 'Title is too long';
  if (!value.author) errors.author = 'Author is required';
  else if (value.author.length > 200) errors.author = 'Author is too long';
  if (!value.edition) errors.edition = 'Edition is required';
  else if (value.edition.length > 30) errors.edition = 'Edition is too long';
  if (!/^[A-Z]{2,4}\d{2,4}$/.test(value.courseCode)) errors.courseCode = 'Use a course code like CS201';
  if (!value.department) errors.department = 'Department is required';
  else if (value.department.length > 80) errors.department = 'Department is too long';
  if (!CONDITIONS.includes(value.condition)) errors.condition = 'Pick a condition';
  if (value.isbn && !isValidIsbn(value.isbn)) errors.isbn = 'ISBN must be 10 or 13 digits';
  return { value, errors };
}

export function validateRegister(input = {}) {
  const errors = {};
  const value = {
    name: str(input.name),
    email: str(input.email).toLowerCase(),
    department: str(input.department),
    password: typeof input.password === 'string' ? input.password : '',
  };
  if (value.name.length < 2 || value.name.length > 60) errors.name = 'Name must be 2–60 characters';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.email) || value.email.length > 120) errors.email = 'Enter a valid email';
  if (value.department.length < 2 || value.department.length > 80) errors.department = 'Department is required';
  // bcrypt only uses the first 72 bytes, so cap it
  if (value.password.length < 8 || value.password.length > 72) errors.password = 'Password must be 8–72 characters';
  return { value, errors };
}

export function validateReview(input = {}) {
  const errors = {};
  const rating = Number(input.rating);
  const comment = str(input.comment);
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) errors.rating = 'Rating must be 1–5';
  if (comment.length > 200) errors.comment = 'Comment must be 200 characters or fewer';
  return { value: { rating, comment }, errors };
}

export function validateCourseCode(input = {}) {
  const courseCode = normalizeCourseCode(input.courseCode);
  const errors = /^[A-Z]{2,4}\d{2,4}$/.test(courseCode) ? {} : { courseCode: 'Use a course code like CS201' };
  return { value: { courseCode }, errors };
}
