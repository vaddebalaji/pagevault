import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { api, getToken, setToken } from '../api.js';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

const DEFAULT_CONFIG = { loanDays: 7, soonDays: 2, maxActiveBorrows: 3, demoTools: false };

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [config, setConfig] = useState(DEFAULT_CONFIG);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    api.config().then(setConfig).catch(() => {});
    if (!getToken()) return setReady(true);
    api.me().then((r) => setUser(r.user)).catch(() => setToken(null)).finally(() => setReady(true));
  }, []);

  const finish = ({ token, user: u }) => { setToken(token); setUser(u); return u; };
  const login = useCallback((email, password) => api.login(email, password).then(finish), []);
  const register = useCallback((data) => api.register(data).then(finish), []);
  const logout = useCallback(() => { setToken(null); setUser(null); }, []);

  return <AuthContext.Provider value={{ user, config, ready, login, register, logout }}>{children}</AuthContext.Provider>;
}
