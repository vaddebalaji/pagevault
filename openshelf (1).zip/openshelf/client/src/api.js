const TOKEN_KEY = 'openshelf:token';
export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (t) => (t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY));

async function call(method, url, body) {
  const token = getToken();
  const res = await fetch(`/api${url}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || 'Request failed');
    err.status = res.status;
    err.fields = data.errors;
    throw err;
  }
  return data;
}

export const api = {
  config: () => call('GET', '/config'),
  login: (email, password) => call('POST', '/auth/login', { email, password }),
  register: (data) => call('POST', '/auth/register', data),
  me: () => call('GET', '/auth/me'),
  books: () => call('GET', '/books'),
  book: (id) => call('GET', `/books/${id}`),
  addBook: (b) => call('POST', '/books', b),
  setAvailable: (id, available) => call('PATCH', `/books/${id}`, { available }),
  deleteBook: (id) => call('DELETE', `/books/${id}`),
  requestBook: (id, message) => call('POST', `/books/${id}/request`, { message }),
  myRequests: () => call('GET', '/requests/mine'),
  approve: (id) => call('POST', `/requests/${id}/approve`),
  reject: (id) => call('POST', `/requests/${id}/reject`),
  markReturned: (id) => call('POST', `/requests/${id}/return`),
  review: (id, rating, comment) => call('POST', `/requests/${id}/review`, { rating, comment }),
  shiftDue: (id, days) => call('POST', `/requests/${id}/shift`, { days }),
  notifications: () => call('GET', '/notifications'),
  readNotifications: () => call('POST', '/notifications/read'),
  wishlist: () => call('GET', '/wishlist'),
  addWish: (courseCode) => call('POST', '/wishlist', { courseCode }),
  removeWish: (id) => call('DELETE', `/wishlist/${id}`),
  isbn: (isbn) => call('GET', `/isbn/${encodeURIComponent(isbn)}`),
};
