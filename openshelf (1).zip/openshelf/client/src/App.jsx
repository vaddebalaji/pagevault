import { Link, NavLink, Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext.jsx';
import ReminderBanner from './components/ReminderBanner.jsx';
import NotificationBell from './components/NotificationBell.jsx';
import Catalog from './pages/Catalog.jsx';
import BookDetail from './pages/BookDetail.jsx';
import ListBook from './pages/ListBook.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Login from './pages/Login.jsx';

function Protected({ children }) {
  const { user, ready } = useAuth();
  if (!ready) return null;
  return user ? children : <Navigate to="/login" replace />;
}

export default function App() {
  const { user, logout } = useAuth();
  const link = ({ isActive }) =>
    `rounded-md px-3 py-1.5 text-sm ${isActive ? 'bg-white/15 text-white' : 'text-white/80 hover:bg-white/10'}`;

  return (
    <div className="min-h-screen">
      <header className="bg-ink">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3">
          <Link to="/" className="font-serif text-2xl font-bold text-white">
            Open<span className="text-teal-300">Shelf</span>
          </Link>
          <nav className="flex flex-1 gap-1">
            <NavLink to="/" end className={link}>Catalog</NavLink>
            <NavLink to="/list" className={link}>List a Book</NavLink>
            <NavLink to="/exchanges" className={link}>My Exchanges</NavLink>
          </nav>
          {user ? (
            <div className="flex items-center gap-2">
              <NotificationBell key={user.id} />
              <span className="hidden text-sm text-white/80 sm:inline">{user.name}</span>
              <button onClick={logout} className="text-sm text-white/70 hover:text-white">Log out</button>
            </div>
          ) : (
            <Link to="/login" className="btn-primary">Log in</Link>
          )}
        </div>
      </header>
      {user && <ReminderBanner key={user.id} />}
      <main className="mx-auto max-w-6xl px-4 py-6">
        <Routes>
          <Route path="/" element={<Catalog />} />
          <Route path="/books/:id" element={<BookDetail />} />
          <Route path="/login" element={<Login />} />
          <Route path="/list" element={<Protected><ListBook /></Protected>} />
          <Route path="/exchanges" element={<Protected><Dashboard /></Protected>} />
          <Route path="*" element={<p>Page not found.</p>} />
        </Routes>
      </main>
    </div>
  );
}
