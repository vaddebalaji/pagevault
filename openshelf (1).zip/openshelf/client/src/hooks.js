import { useEffect, useState } from 'react';

export const DAY = 86_400_000;

// Re-renders on an interval so countdowns and overdue state stay live (no server cron needed).
export function useNow(ms = 1000) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), ms);
    return () => clearInterval(t);
  }, [ms]);
  return now;
}

// 'overdue' | 'soon' (within soonDays) | 'ok'. soonDays comes from the server's /api/config.
export function dueState(dueDate, now = Date.now(), soonDays = 2) {
  if (!dueDate) return 'ok';
  const left = dueDate - now;
  if (left < 0) return 'overdue';
  if (left <= soonDays * DAY) return 'soon';
  return 'ok';
}

export function splitDuration(ms) {
  const diff = Math.abs(ms);
  return {
    d: Math.floor(diff / DAY),
    h: Math.floor((diff % DAY) / 3_600_000),
    m: Math.floor((diff % 3_600_000) / 60_000),
    s: Math.floor((diff % 60_000) / 1000),
  };
}
