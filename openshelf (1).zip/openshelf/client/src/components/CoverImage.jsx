import { useState } from 'react';

const PALETTE = ['#0e7c7b', '#14213d', '#7c3a5a', '#9a5b13', '#2f5d8a', '#4b5d3a'];

// SVG fallback cover: shows title + course code, colour derived from course code.
function FallbackCover({ title, courseCode }) {
  const color = PALETTE[[...courseCode].reduce((a, c) => a + c.charCodeAt(0), 0) % PALETTE.length];
  const words = title.split(' ');
  const lines = [];
  let line = '';
  for (const w of words) {
    if ((line + ' ' + w).trim().length > 16) { lines.push(line.trim()); line = w; }
    else line += ' ' + w;
  }
  lines.push(line.trim());
  return (
    <svg viewBox="0 0 200 280" className="h-full w-full" role="img" aria-label={`Cover for ${title}`}>
      <rect width="200" height="280" fill={color} />
      <rect x="14" y="0" width="6" height="280" fill="#ffffff" opacity="0.18" />
      <rect x="34" y="28" width="132" height="1.5" fill="#fff" opacity="0.6" />
      {lines.slice(0, 5).map((l, i) => (
        <text key={i} x="34" y={72 + i * 24} fill="#fff" fontFamily="Newsreader, Georgia, serif" fontSize="19" fontWeight="700">{l}</text>
      ))}
      <text x="34" y="250" fill="#fff" opacity="0.9" fontFamily="IBM Plex Sans, sans-serif" fontSize="15" fontWeight="600">{courseCode}</text>
    </svg>
  );
}

export default function CoverImage({ book, className = '' }) {
  const [failed, setFailed] = useState(!book.isbn);
  return (
    <div className={`overflow-hidden rounded bg-slate-200 ${className}`}>
      {failed ? (
        <FallbackCover title={book.title} courseCode={book.courseCode} />
      ) : (
        <img
          src={`https://covers.openlibrary.org/b/isbn/${book.isbn}-M.jpg?default=false`}
          alt={`Cover of ${book.title}`}
          loading="lazy"
          className="h-full w-full object-cover"
          onError={() => setFailed(true)}
        />
      )}
    </div>
  );
}
