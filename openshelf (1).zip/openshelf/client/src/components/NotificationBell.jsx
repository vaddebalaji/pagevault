import { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function NotificationBell() {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const load = () => api.notifications().then(setItems).catch(() => {});
    load();
    const t = setInterval(load, 10_000);
    return () => clearInterval(t);
  }, []);

  const unread = items.filter((n) => !n.read).length;
  const toggle = () => {
    if (!open && unread) api.readNotifications().then(() => setTimeout(() => api.notifications().then(setItems), 3000));
    setOpen(!open);
  };

  return (
    <div className="relative">
      <button onClick={toggle} className="relative rounded-md px-2 py-1 text-sm text-white/90 hover:bg-white/10" aria-label="Notifications">
        Alerts
        {unread > 0 && <span className="ml-1 rounded-full bg-amber-400 px-1.5 text-xs font-semibold text-ink">{unread}</span>}
      </button>
      {open && (
        <div className="absolute right-0 z-20 mt-2 w-72 rounded-lg border border-slate-200 bg-white p-2 text-ink shadow-lg">
          {items.length === 0 && <p className="p-3 text-sm text-slate-500">Nothing yet.</p>}
          <ul className="max-h-72 divide-y divide-slate-100 overflow-auto">
            {items.slice(0, 15).map((n) => (
              <li key={n.id} className={`p-2 text-sm ${n.read ? 'text-slate-500' : 'font-medium'}`}>
                {n.message}
                <div className="text-xs text-slate-400">{new Date(n.createdAt).toLocaleString()}</div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
