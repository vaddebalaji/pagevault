import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { useNow, dueState } from '../hooks.js';
import { useAuth } from '../context/AuthContext.jsx';

// Shows banners + browser notifications for borrowed books that are due soon / overdue.
export default function ReminderBanner() {
  const { user, config } = useAuth();
  const [loans, setLoans] = useState([]);
  const now = useNow(15_000);
  const notified = useRef(new Set());

  useEffect(() => {
    if (!user) return;
    const load = () => api.myRequests().then((r) => setLoans(r.borrowing.filter((x) => x.status === 'approved'))).catch(() => {});
    load();
    const t = setInterval(load, 20_000);
    return () => clearInterval(t);
  }, [user]);

  const alerts = loans
    .map((l) => ({ loan: l, state: dueState(l.dueDate, now, config.soonDays) }))
    .filter((a) => a.state !== 'ok');

  useEffect(() => {
    if (!alerts.length || !('Notification' in window)) return;
    if (Notification.permission === 'default') Notification.requestPermission();
    if (Notification.permission !== 'granted') return;
    alerts.forEach(({ loan, state }) => {
      const key = `${loan.id}:${state}`;
      if (notified.current.has(key)) return;
      notified.current.add(key);
      new Notification(state === 'overdue' ? 'Book overdue' : 'Book due soon', {
        body: `"${loan.book.title}" is ${state === 'overdue' ? 'overdue' : `due within ${config.soonDays} days`}. Return it to ${loan.lender.name}.`,
      });
    });
  }, [alerts.map((a) => `${a.loan.id}:${a.state}`).join(',')]); // eslint-disable-line

  if (!alerts.length) return null;
  return (
    <div className="space-y-1">
      {alerts.map(({ loan, state }) => (
        <div
          key={loan.id}
          className={`px-4 py-2 text-center text-sm font-medium ${state === 'overdue' ? 'bg-red-600 text-white' : 'bg-amber-300 text-amber-950'}`}
        >
          {state === 'overdue' ? 'Overdue: ' : 'Due soon: '}
          “{loan.book.title}” — {state === 'overdue' ? 'please return it to' : 'return it to'} {loan.lender.name}.{' '}
          <Link to="/exchanges" className="underline">View</Link>
        </div>
      ))}
    </div>
  );
}
