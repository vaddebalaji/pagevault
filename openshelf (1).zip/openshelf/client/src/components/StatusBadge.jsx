const STYLES = {
  available: 'bg-emerald-100 text-emerald-800 ring-emerald-200',
  reserved: 'bg-amber-100 text-amber-800 ring-amber-200',
  borrowed: 'bg-rose-100 text-rose-800 ring-rose-200',
};
const LABELS = { available: 'Available', reserved: 'Reserved', borrowed: 'Borrowed' };

export default function StatusBadge({ status }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ${STYLES[status]}`}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {LABELS[status]}
    </span>
  );
}
