import { Link } from 'react-router-dom';
import CoverImage from './CoverImage.jsx';
import StatusBadge from './StatusBadge.jsx';

export default function BookCard({ book }) {
  return (
    <Link
      to={`/books/${book.id}`}
      className="group flex gap-4 rounded-lg border border-slate-200 bg-white p-3 transition hover:border-spine hover:shadow-sm"
    >
      <CoverImage book={book} className="aspect-[5/7] w-24 shrink-0" />
      <div className="flex min-w-0 flex-1 flex-col">
        <span className="mb-1 w-fit rounded bg-ink px-1.5 py-0.5 text-xs font-semibold tracking-wide text-white">{book.courseCode}</span>
        <h3 className="line-clamp-2 text-lg font-bold leading-snug group-hover:text-spine">{book.title}</h3>
        <p className="line-clamp-1 text-sm text-slate-600">{book.author}</p>
        <p className="mt-0.5 text-xs text-slate-500">{book.edition} ed. · {book.condition}</p>
        <div className="mt-auto flex items-center justify-between pt-2">
          <StatusBadge status={book.status} />
          <span className="truncate pl-2 text-xs text-slate-500">{book.owner?.name}</span>
        </div>
      </div>
    </Link>
  );
}
