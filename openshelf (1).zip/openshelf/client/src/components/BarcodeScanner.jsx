import { useEffect, useRef, useState } from 'react';

// Camera ISBN scanner (QuaggaJS fork, loaded on demand so it doesn't bloat the main bundle).
export default function BarcodeScanner({ onDetected, onClose }) {
  const box = useRef(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let Quagga;
    let handler;
    let cancelled = false;
    (async () => {
      try {
        Quagga = (await import('@ericblade/quagga2')).default;
        if (cancelled) return;
        await new Promise((resolve, reject) =>
          Quagga.init(
            {
              inputStream: { type: 'LiveStream', target: box.current, constraints: { facingMode: 'environment' } },
              decoder: { readers: ['ean_reader'] }, // ISBN-13 barcodes are EAN-13
              locate: true,
            },
            (err) => (err ? reject(err) : resolve())
          )
        );
        if (cancelled) return;
        handler = (result) => {
          const code = result?.codeResult?.code;
          if (code && /^97[89]\d{10}$/.test(code)) onDetected(code);
        };
        Quagga.onDetected(handler);
        Quagga.start();
      } catch {
        setError('Could not open the camera. Check permissions, or type the ISBN instead.');
      }
    })();
    return () => {
      cancelled = true;
      if (Quagga) { if (handler) Quagga.offDetected(handler); try { Quagga.stop(); } catch { /* not started */ } }
    };
  }, []); // eslint-disable-line

  return (
    <div className="rounded-lg border border-slate-300 bg-white p-3">
      <div ref={box} className="relative aspect-video w-full overflow-hidden rounded bg-black [&>video]:h-full [&>video]:w-full [&>video]:object-cover [&>canvas]:hidden" />
      {error ? <p className="mt-2 text-sm text-red-600">{error}</p> : <p className="mt-2 text-xs text-slate-500">Point the camera at the barcode on the back cover.</p>}
      <button type="button" className="btn-ghost mt-2" onClick={onClose}>Close scanner</button>
    </div>
  );
}
