export function StarDisplay({ rating, count }) {
  if (!count) return <span className="text-xs text-slate-400">No ratings yet</span>;
  return (
    <span className="text-sm" title={`${rating} out of 5`}>
      <span className="text-amber-500">{'★'.repeat(Math.round(rating))}</span>
      <span className="text-slate-300">{'★'.repeat(5 - Math.round(rating))}</span>
      <span className="ml-1 text-xs text-slate-500">{rating} ({count})</span>
    </span>
  );
}

export function StarPicker({ value, onChange }) {
  return (
    <div className="inline-flex" role="radiogroup" aria-label="Rating">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n} type="button" role="radio" aria-checked={value === n} aria-label={`${n} star${n > 1 ? 's' : ''}`}
          onClick={() => onChange(n)}
          className={`text-2xl leading-none ${n <= value ? 'text-amber-500' : 'text-slate-300 hover:text-amber-300'}`}
        >★</button>
      ))}
    </div>
  );
}
