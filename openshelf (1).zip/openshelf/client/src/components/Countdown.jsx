import { useNow, dueState, splitDuration } from '../hooks.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function Countdown({ dueDate }) {
  const { config } = useAuth();
  const now = useNow(1000);
  const state = dueState(dueDate, now, config.soonDays);
  const { d, h, m, s } = splitDuration(dueDate - now);
  const text = `${d}d ${String(h).padStart(2, '0')}h ${String(m).padStart(2, '0')}m ${String(s).padStart(2, '0')}s`;
  const style = {
    ok: 'bg-teal-50 text-teal-800 ring-teal-200',
    soon: 'bg-amber-50 text-amber-800 ring-amber-300',
    overdue: 'bg-red-50 text-red-700 ring-red-300',
  }[state];
  return (
    <div className={`inline-flex items-baseline gap-2 rounded-md px-3 py-1.5 font-mono text-sm ring-1 ${style}`}>
      <span className="font-sans text-xs font-medium">{state === 'overdue' ? 'Overdue by' : 'Due in'}</span>
      {text}
    </div>
  );
}
