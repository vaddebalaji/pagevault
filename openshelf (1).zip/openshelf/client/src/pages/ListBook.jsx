import { lazy, Suspense, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';

const BarcodeScanner = lazy(() => import('../components/BarcodeScanner.jsx'));

const EMPTY = { title: '', author: '', edition: '', courseCode: '', department: '', isbn: '', condition: 'Good' };
const FIELDS = [
  ['title', 'Title', 'Operating System Concepts'],
  ['author', 'Author', 'Silberschatz, Galvin, Gagne'],
  ['edition', 'Edition', '10th'],
  ['courseCode', 'Course code', 'CS301'],
  ['department', 'Department', 'Computer Science'],
];

export default function ListBook() {
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [lookup, setLookup] = useState({ busy: false, msg: '' });
  const [scanning, setScanning] = useState(false);
  const nav = useNavigate();

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  // Open Library auto-fill (via our API so the browser never calls a third party directly)
  const autofill = async (isbn = form.isbn) => {
    setLookup({ busy: true, msg: '' });
    try {
      const info = await api.isbn(isbn);
      setForm((f) => ({
        ...f, isbn: info.isbn,
        title: f.title || info.title,
        author: f.author || info.author,
        edition: f.edition || (info.publishDate ? `Pub. ${info.publishDate}` : ''),
      }));
      setLookup({ busy: false, msg: 'Filled from Open Library. Please check the edition and add the course code.' });
    } catch (e) {
      setLookup({ busy: false, msg: e.message });
    }
  };

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setErrors({}); setError('');
    try {
      const book = await api.addBook(form);
      nav(`/books/${book.id}`);
    } catch (err) {
      setErrors(err.fields || {});
      setError(err.message);
    } finally { setBusy(false); }
  };

  return (
    <div className="mx-auto max-w-xl">
      <h1 className="text-3xl font-bold">List a book</h1>
      <p className="mb-5 text-sm text-slate-600">Scan or type the ISBN to auto-fill, then tag it with the course code so classmates can find it.</p>
      <form onSubmit={submit} className="space-y-4 rounded-lg border border-slate-200 bg-white p-5" noValidate>
        <div>
          <label className="block text-sm">
            <span className="mb-1 block font-medium">ISBN (optional)</span>
            <div className="flex gap-2">
              <input className="input" value={form.isbn} onChange={set('isbn')} placeholder="9781119800361" inputMode="numeric" />
              <button type="button" className="btn-ghost shrink-0" disabled={!form.isbn || lookup.busy} onClick={() => autofill()}>
                {lookup.busy ? 'Looking up…' : 'Auto-fill'}
              </button>
              <button type="button" className="btn-ghost shrink-0" onClick={() => setScanning((s) => !s)}>Scan</button>
            </div>
            {errors.isbn && <span className="mt-1 block text-xs text-red-600">{errors.isbn}</span>}
            {lookup.msg && <span className="mt-1 block text-xs text-slate-500">{lookup.msg}</span>}
          </label>
          {scanning && (
            <div className="mt-2">
              <Suspense fallback={<p className="text-sm text-slate-500">Loading scanner…</p>}>
                <BarcodeScanner
                  onClose={() => setScanning(false)}
                  onDetected={(code) => { setScanning(false); setForm((f) => ({ ...f, isbn: code })); autofill(code); }}
                />
              </Suspense>
            </div>
          )}
        </div>
        {FIELDS.map(([k, label, ph]) => (
          <label key={k} className="block text-sm">
            <span className="mb-1 block font-medium">{label}</span>
            <input className="input" value={form[k]} onChange={set(k)} placeholder={ph} />
            {errors[k] && <span className="mt-1 block text-xs text-red-600">{errors[k]}</span>}
          </label>
        ))}
        <label className="block text-sm">
          <span className="mb-1 block font-medium">Condition</span>
          <select className="input" value={form.condition} onChange={set('condition')}>
            {['Like New', 'Good', 'Fair', 'Poor'].map((c) => <option key={c}>{c}</option>)}
          </select>
        </label>
        {error && !Object.keys(errors).length && <p className="text-sm text-red-600">{error}</p>}
        <button className="btn-primary w-full" disabled={busy}>{busy ? 'Listing…' : 'List book'}</button>
      </form>
    </div>
  );
}
