import { useEffect, useMemo, useState } from 'react';
import { api } from '../api.js';
import BookCard from '../components/BookCard.jsx';
import { useAuth } from '../context/AuthContext.jsx';

const STATUSES = [['all', 'All'], ['available', 'Available'], ['reserved', 'Reserved'], ['borrowed', 'Borrowed']];

export default function Catalog() {
  const { user } = useAuth();
  const [watchMsg, setWatchMsg] = useState('');
  const [books, setBooks] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('all');
  const [dept, setDept] = useState('all');

  useEffect(() => {
    api.books().then(setBooks).catch((e) => setError(e.message)).finally(() => setLoading(false));
  }, []);

  const departments = useMemo(() => [...new Set(books.map((b) => b.department))].sort(), [books]);

  // Real-time filtering: course code, title, author or department
  const results = useMemo(() => {
    const term = q.trim().toLowerCase().replace(/\s|-/g, '');
    return books.filter((b) => {
      if (status !== 'all' && b.status !== status) return false;
      if (dept !== 'all' && b.department !== dept) return false;
      if (!term) return true;
      return [b.courseCode, b.title, b.author, b.department]
        .some((f) => f.toLowerCase().replace(/\s|-/g, '').includes(term));
    });
  }, [books, q, status, dept]);

  const looksLikeCourse = /^[a-z]{2,4}\s?-?\d{2,4}$/i.test(q.trim());
  const watch = () =>
    api.addWish(q).then((w) => setWatchMsg(`We'll alert you when a ${w.courseCode} book becomes available.`)).catch((e) => setWatchMsg(e.message));

  return (
    <>
      <section className="mb-6">
        <h1 className="text-4xl font-bold">Find your course books</h1>
        <p className="mt-1 text-slate-600">Borrow from students who already took the class. Try <button className="font-mono text-spine underline" onClick={() => setQ('CS301')}>CS301</button>.</p>
        <div className="mt-4 grid gap-3 md:grid-cols-[1fr_auto_auto]">
          <input
            className="input"
            placeholder="Search by course code, title, author or department"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            aria-label="Search books"
          />
          <select className="input md:w-56" value={dept} onChange={(e) => setDept(e.target.value)} aria-label="Department">
            <option value="all">All departments</option>
            {departments.map((d) => <option key={d}>{d}</option>)}
          </select>
          <div className="flex overflow-hidden rounded-md border border-slate-300 bg-white text-sm">
            {STATUSES.map(([v, label]) => (
              <button
                key={v}
                onClick={() => setStatus(v)}
                className={`px-3 py-2 ${status === v ? 'bg-spine text-white' : 'hover:bg-slate-50'}`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {error && <p className="rounded-md bg-red-50 p-3 text-sm text-red-700">{error}. Is the API running on port 3001?</p>}
      {loading && <p className="text-slate-500">Loading catalog…</p>}
      {!loading && !error && (
        <>
          <p className="mb-3 text-sm text-slate-500">{results.length} of {books.length} books</p>
          {results.length === 0 ? (
            <div className="rounded-lg border border-dashed border-slate-300 p-8 text-center text-slate-500">
              <p>No books match that search.</p>
              {user && looksLikeCourse && (
                <p className="mt-3">
                  <button className="btn-primary" onClick={watch}>Notify me when {q.trim().toUpperCase()} is available</button>
                </p>
              )}
              {watchMsg && <p className="mt-2 text-sm text-slate-600">{watchMsg}</p>}
            </div>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {results.map((b) => <BookCard key={b.id} book={b} />)}
            </div>
          )}
        </>
      )}
    </>
  );
}
