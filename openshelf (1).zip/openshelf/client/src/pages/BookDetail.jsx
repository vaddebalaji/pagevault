import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';
import CoverImage from '../components/CoverImage.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import Countdown from '../components/Countdown.jsx';
import { StarDisplay } from '../components/Stars.jsx';

export default function BookDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [book, setBook] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const load = () => api.book(id).then(setBook).catch((e) => setError(e.message));
  useEffect(() => { load(); }, [id, user?.id]); // eslint-disable-line

  const request = async () => {
    setBusy(true); setError('');
    try { await api.requestBook(id, message); setMessage(''); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); load(); } // reload either way so a stale badge is corrected
  };

  if (!book) return <p className="text-slate-500">{error || 'Loading…'}</p>;
  const isOwner = user?.id === book.ownerId;
  const req = book.activeRequest;

  return (
    <div className="grid gap-8 md:grid-cols-[260px_1fr]">
      <CoverImage book={book} className="aspect-[5/7] w-full max-w-[260px] shadow-md" />
      <div>
        <Link to="/" className="text-sm text-spine hover:underline">← Back to catalog</Link>
        <div className="mt-2 flex items-center gap-2">
          <span className="rounded bg-ink px-2 py-0.5 text-xs font-semibold text-white">{book.courseCode}</span>
          <StatusBadge status={book.status} />
        </div>
        <h1 className="mt-2 text-4xl font-bold leading-tight">{book.title}</h1>
        <p className="text-lg text-slate-600">{book.author}</p>

        <dl className="mt-5 grid max-w-md grid-cols-2 gap-y-2 text-sm">
          <dt className="text-slate-500">Edition</dt><dd>{book.edition}</dd>
          <dt className="text-slate-500">Condition</dt><dd>{book.condition}</dd>
          <dt className="text-slate-500">Department</dt><dd>{book.department}</dd>
          <dt className="text-slate-500">ISBN</dt><dd className="font-mono">{book.isbn || '—'}</dd>
          <dt className="text-slate-500">Listed by</dt><dd>{book.owner?.name}</dd>
          <dt className="text-slate-500">Lender trust</dt><dd><StarDisplay rating={book.owner?.rating} count={book.owner?.ratingCount} /></dd>
        </dl>

        <div className="mt-6 max-w-md rounded-lg border border-slate-200 bg-white p-4">
          {error && <p className="mb-3 rounded bg-red-50 p-2 text-sm text-red-700">{error}</p>}
          {!user && <p className="text-sm">Please <Link className="text-spine underline" to="/login">log in</Link> to request this book.</p>}
          {user && isOwner && <p className="text-sm text-slate-600">This is your book. Manage it in <Link className="text-spine underline" to="/exchanges">My Exchanges</Link>.</p>}
          {user && !isOwner && book.status === 'available' && (
            <>
              <textarea
                className="input mb-3" rows={2} maxLength={300}
                placeholder="Optional note to the lender (e.g. preferred handoff spot)"
                value={message} onChange={(e) => setMessage(e.target.value)}
              />
              <button className="btn-primary w-full" disabled={busy} onClick={request}>
                {busy ? 'Requesting…' : 'Request Borrow'}
              </button>
            </>
          )}
          {user && !isOwner && book.status === 'reserved' && (
            <p className="text-sm text-slate-600">
              {req?.isMine ? 'You have a pending request for this book.' : 'Someone has already requested this book.'}
            </p>
          )}
          {user && !isOwner && book.status === 'borrowed' && (
            <div className="space-y-2 text-sm text-slate-600">
              <p>Currently on loan.</p>
              {req?.dueDate && <Countdown dueDate={req.dueDate} />}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
