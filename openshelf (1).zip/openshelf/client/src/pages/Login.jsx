import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

const DEMO = [['Aarav (Student A)', 'aarav@campus.edu'], ['Meera (Student B)', 'meera@campus.edu'], ['Kabir', 'kabir@campus.edu']];

export default function Login() {
  const { login, register, config } = useAuth();
  const nav = useNavigate();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', department: '', password: '' });
  const [errors, setErrors] = useState({});
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setErrors({}); setError('');
    try {
      if (mode === 'login') await login(form.email, form.password);
      else await register(form);
      nav('/');
    } catch (err) {
      setError(err.message); setErrors(err.fields || {});
    } finally { setBusy(false); }
  };

  const fields = mode === 'login'
    ? [['email', 'Email', 'email'], ['password', 'Password', 'password']]
    : [['name', 'Full name', 'text'], ['email', 'Email', 'email'], ['department', 'Department', 'text'], ['password', 'Password (8+ characters)', 'password']];

  return (
    <div className="mx-auto max-w-md">
      <h1 className="mb-4 text-3xl font-bold">{mode === 'login' ? 'Welcome back' : 'Join OpenShelf'}</h1>
      <form onSubmit={submit} className="space-y-3 rounded-lg border border-slate-200 bg-white p-5" noValidate>
        {fields.map(([k, label, type]) => (
          <label key={k} className="block text-sm">
            <span className="mb-1 block font-medium">{label}</span>
            <input className="input" type={type} value={form[k]} onChange={set(k)} autoComplete={k === 'password' ? (mode === 'login' ? 'current-password' : 'new-password') : k} />
            {errors[k] && <span className="mt-1 block text-xs text-red-600">{errors[k]}</span>}
          </label>
        ))}
        {error && !Object.keys(errors).length && <p className="text-sm text-red-600">{error}</p>}
        <button className="btn-primary w-full" disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Log in' : 'Create account'}</button>
        <button type="button" className="w-full text-sm text-spine underline" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setErrors({}); setError(''); }}>
          {mode === 'login' ? 'New here? Create an account' : 'Have an account? Log in'}
        </button>
      </form>
      {config.demoTools && mode === 'login' && (
        <div className="mt-4 rounded-lg border border-dashed border-slate-300 p-3 text-sm">
          <p className="mb-2 text-slate-600">Demo accounts (password <code className="font-mono">password123</code>):</p>
          <div className="flex flex-wrap gap-2">
            {DEMO.map(([label, email]) => (
              <button key={email} type="button" className="btn-ghost" onClick={() => setForm({ ...form, email, password: 'password123' })}>{label}</button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
