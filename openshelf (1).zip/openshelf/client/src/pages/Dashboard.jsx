import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import Countdown from '../components/Countdown.jsx';
import { StarPicker } from '../components/Stars.jsx';

const TABS = [['lent', 'My Books'], ['borrowed', 'Borrowing'], ['history', 'History'], ['wishlist', 'Wishlist']];

function DemoShift({ id, onDone }) {
  const shift = (days) => api.shiftDue(id, days).then(onDone);
  return (
    <div className="mt-2 flex flex-wrap items-center gap-1 text-xs text-slate-500">
      Demo: shift due date
      <button className="rounded border px-1.5 py-0.5 hover:bg-slate-50" onClick={() => shift(7)}>+7d</button>
      <button className="rounded border px-1.5 py-0.5 hover:bg-slate-50" onClick={() => shift(1)}>1 day left</button>
      <button className="rounded border px-1.5 py-0.5 hover:bg-slate-50" onClick={() => shift(-1)}>Overdue</button>
    </div>
  );
}

function RateForm({ request, onDone }) {
  const [rating, setRating] = useState(0);
  const [error, setError] = useState('');
  const submit = () => api.review(request.id, rating, '').then(onDone).catch((e) => setError(e.message));
  return (
    <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-slate-600">
      Rate punctuality: <StarPicker value={rating} onChange={setRating} />
      <button className="btn-ghost !px-2 !py-1 text-xs" disabled={!rating} onClick={submit}>Submit</button>
      {error && <span className="text-red-600">{error}</span>}
    </div>
  );
}

const contact = (p) => (p.email ? ` (${p.email})` : '');

export default function Dashboard() {
  const { user, config } = useAuth();
  const [tab, setTab] = useState('lent');
  const [mine, setMine] = useState([]);
  const [data, setData] = useState({ lending: [], borrowing: [] });
  const [wishes, setWishes] = useState([]);
  const [wishInput, setWishInput] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(() => {
    Promise.all([api.books(), api.myRequests(), api.wishlist()])
      .then(([books, reqs, w]) => { setMine(books.filter((b) => b.ownerId === user.id)); setData(reqs); setWishes(w); })
      .catch((e) => setError(e.message));
  }, [user.id]);
  useEffect(() => { load(); }, [load]);

  const act = (fn) => async (...args) => {
    setError('');
    try { await fn(...args); } catch (e) { setError(e.message); }
    load();
  };
  const approve = act(api.approve);
  const reject = act(api.reject);
  const markReturned = act(api.markReturned);
  const toggle = act((b) => api.setAvailable(b.id, b.status !== 'available'));
  const remove = act((b) => window.confirm(`Delete "${b.title}"?`) && api.deleteBook(b.id));
  const addWish = act(async () => { await api.addWish(wishInput); setWishInput(''); });
  const removeWish = act(api.removeWish);

  const incoming = data.lending.filter((r) => r.status === 'pending');
  const lentOut = data.lending.filter((r) => r.status === 'approved');
  const borrowing = data.borrowing.filter((r) => ['pending', 'approved'].includes(r.status));
  const history = [...data.lending, ...data.borrowing]
    .filter((r) => ['returned', 'rejected'].includes(r.status))
    .sort((a, b) => (b.returnedAt || b.requestedAt) - (a.returnedAt || a.requestedAt));

  return (
    <>
      <h1 className="mb-4 text-3xl font-bold">My Exchanges</h1>
      <div className="mb-5 flex gap-1 overflow-x-auto border-b border-slate-300">
        {TABS.map(([k, label]) => (
          <button
            key={k}
            onClick={() => setTab(k)}
            className={`-mb-px whitespace-nowrap border-b-2 px-4 py-2 text-sm font-medium ${tab === k ? 'border-spine text-spine' : 'border-transparent text-slate-500 hover:text-ink'}`}
          >
            {label}
            {k === 'lent' && incoming.length > 0 && <span className="ml-1.5 rounded-full bg-amber-400 px-1.5 text-xs text-ink">{incoming.length}</span>}
          </button>
        ))}
      </div>
      {error && <p className="mb-3 rounded bg-red-50 p-2 text-sm text-red-700">{error}</p>}

      {tab === 'lent' && (
        <div className="space-y-8">
          <section>
            <h2 className="mb-2 text-xl font-bold">Requests awaiting you</h2>
            {incoming.length === 0 && <p className="text-sm text-slate-500">No pending requests.</p>}
            <ul className="space-y-2">
              {incoming.map((r) => (
                <li key={r.id} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-amber-200 bg-amber-50 p-3">
                  <div className="text-sm">
                    <b>{r.borrower.name}</b> wants <Link className="underline" to={`/books/${r.bookId}`}>{r.book.title}</Link>
                    {r.message && <p className="mt-0.5 italic text-slate-600">“{r.message}”</p>}
                  </div>
                  <div className="flex gap-2">
                    <button className="btn-primary" onClick={() => approve(r.id)}>Approve</button>
                    <button className="btn-danger" onClick={() => reject(r.id)}>Reject</button>
                  </div>
                </li>
              ))}
            </ul>
          </section>

          <section>
            <h2 className="mb-2 text-xl font-bold">Currently lent out</h2>
            {lentOut.length === 0 && <p className="text-sm text-slate-500">Nothing lent out right now.</p>}
            <ul className="space-y-2">
              {lentOut.map((r) => (
                <li key={r.id} className="rounded-lg border border-slate-200 bg-white p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="text-sm"><b>{r.book.title}</b> with {r.borrower.name}{contact(r.borrower)}</div>
                    <Countdown dueDate={r.dueDate} />
                  </div>
                  <div className="mt-2"><button className="btn-ghost" onClick={() => markReturned(r.id)}>Mark Returned</button></div>
                  {config.demoTools && <DemoShift id={r.id} onDone={load} />}
                </li>
              ))}
            </ul>
          </section>

          <section>
            <h2 className="mb-2 text-xl font-bold">Books I've listed</h2>
            {mine.length === 0 && <p className="text-sm text-slate-500">You haven't listed any books. <Link className="text-spine underline" to="/list">List one</Link>.</p>}
            <ul className="divide-y divide-slate-200 rounded-lg border border-slate-200 bg-white">
              {mine.map((b) => (
                <li key={b.id} className="flex flex-wrap items-center justify-between gap-2 p-3 text-sm">
                  <div>
                    <Link className="font-medium hover:underline" to={`/books/${b.id}`}>{b.title}</Link>
                    <span className="ml-2 font-mono text-xs text-slate-500">{b.courseCode}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <StatusBadge status={b.status} />
                    {['available', 'reserved'].includes(b.status) && !incoming.some((r) => r.bookId === b.id) && (
                      <>
                        <label className="flex cursor-pointer items-center gap-1.5 text-xs text-slate-600">
                          <input type="checkbox" checked={b.status === 'available'} onChange={() => toggle(b)} />
                          Available
                        </label>
                        <button className="text-xs text-red-600 hover:underline" onClick={() => remove(b)}>Delete</button>
                      </>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </section>
        </div>
      )}

      {tab === 'borrowed' && (
        <ul className="space-y-2">
          {borrowing.length === 0 && <p className="text-sm text-slate-500">You aren't borrowing anything. <Link className="text-spine underline" to="/">Browse the catalog</Link>.</p>}
          {borrowing.map((r) => (
            <li key={r.id} className="rounded-lg border border-slate-200 bg-white p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-sm">
                  <Link className="font-medium hover:underline" to={`/books/${r.bookId}`}>{r.book.title}</Link>
                  <div className="text-slate-500">from {r.lender.name}{contact(r.lender)}</div>
                </div>
                {r.status === 'pending'
                  ? <span className="rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-medium text-amber-800">Awaiting approval</span>
                  : <Countdown dueDate={r.dueDate} />}
              </div>
              {r.status === 'approved' && (
                <>
                  <div className="mt-2"><button className="btn-ghost" onClick={() => markReturned(r.id)}>Mark Returned</button></div>
                  {config.demoTools && <DemoShift id={r.id} onDone={load} />}
                </>
              )}
            </li>
          ))}
        </ul>
      )}

      {tab === 'history' && (
        <ul className="divide-y divide-slate-200 rounded-lg border border-slate-200 bg-white">
          {history.length === 0 && <li className="p-4 text-sm text-slate-500">No completed exchanges yet.</li>}
          {history.map((r) => (
            <li key={r.id} className="p-3 text-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <b>{r.book.title}</b>
                  <span className="ml-2 text-slate-500">
                    {r.lenderId === user.id ? `lent to ${r.borrower.name}` : `borrowed from ${r.lender.name}`}
                  </span>
                </div>
                <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${r.status === 'returned' ? (r.onTime ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-700') : 'bg-slate-100 text-slate-600'}`}>
                  {r.status === 'returned' ? (r.onTime ? 'Returned on time' : 'Returned late') : 'Declined'}
                </span>
              </div>
              {r.status === 'returned' && !r.reviewed && <RateForm request={r} onDone={load} />}
            </li>
          ))}
        </ul>
      )}

      {tab === 'wishlist' && (
        <div className="max-w-md">
          <p className="mb-3 text-sm text-slate-600">Get an alert when a book for one of these courses becomes available.</p>
          <div className="mb-3 flex gap-2">
            <input className="input" placeholder="Course code, e.g. CS201" value={wishInput} onChange={(e) => setWishInput(e.target.value)} />
            <button className="btn-primary shrink-0" disabled={!wishInput.trim()} onClick={() => addWish()}>Watch</button>
          </div>
          <ul className="divide-y divide-slate-200 rounded-lg border border-slate-200 bg-white">
            {wishes.length === 0 && <li className="p-3 text-sm text-slate-500">Not watching any courses.</li>}
            {wishes.map((w) => (
              <li key={w.id} className="flex items-center justify-between p-3 text-sm">
                <span className="font-mono">{w.courseCode}</span>
                <button className="text-xs text-red-600 hover:underline" onClick={() => removeWish(w.id)}>Remove</button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </>
  );
}
