import { describe, expect, it } from 'vitest';
import { DAY, dueState, splitDuration } from '../src/hooks.js';

const now = 1_700_000_000_000;

describe('dueState', () => {
  it('is ok when more than soonDays remain', () => expect(dueState(now + 5 * DAY, now, 2)).toBe('ok'));
  it('is soon within soonDays', () => expect(dueState(now + DAY, now, 2)).toBe('soon'));
  it('is soon exactly at the boundary', () => expect(dueState(now + 2 * DAY, now, 2)).toBe('soon'));
  it('is overdue once past due', () => expect(dueState(now - 1, now, 2)).toBe('overdue'));
  it('treats a missing due date as ok', () => expect(dueState(null, now)).toBe('ok'));
  it('respects a different soonDays config', () => expect(dueState(now + 3 * DAY, now, 3)).toBe('soon'));
});

describe('splitDuration', () => {
  it('splits milliseconds into d/h/m/s', () => {
    expect(splitDuration(2 * DAY + 3 * 3_600_000 + 4 * 60_000 + 5000)).toEqual({ d: 2, h: 3, m: 4, s: 5 });
  });
  it('uses the absolute value for overdue durations', () => {
    expect(splitDuration(-90_000)).toEqual({ d: 0, h: 0, m: 1, s: 30 });
  });
});
