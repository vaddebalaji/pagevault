# OpenShelf: Campus Peer-to-Peer Book Exchange (PageVault Hackathon)

React + React Router + Tailwind frontend, Node/Express API, **SQLite** database, **JWT** auth, **Vitest** test suite.

## Run
```bash
npm run install:all     # root + server + client deps
npm run dev             # API on :3001, web on :5173
npm test                # server (service + API tests) and client unit tests
```
Open http://localhost:5173. On first start the API seeds 4 demo users and 35 textbooks
(demo password for every seeded user: `password123`). `npm run reset-db` wipes and re-seeds.
Copy `server/.env.example` for configuration; `JWT_SECRET` is **required** when `NODE_ENV=production`.

## Demo flow (from the brief)
1. Log in as **aarav@campus.edu**. He already owns *Operating System Concepts* (CS301), or list another via *List a Book*
   (type an ISBN and press **Auto-fill** to pull metadata from Open Library, or **Scan** a barcode with the camera).
2. Log out, log in as **meera@campus.edu**, search `CS301`, open the book, **Request Borrow**. Badge flips to *Reserved*.
3. Back as Aarav: **My Exchanges, Approve**. Badge becomes *Borrowed*, due date = +7 days.
4. As Meera: live countdown + reminder banner. The **Demo: shift due date** buttons (dev mode only) simulate
   "due soon" / "overdue" and trigger banners, browser notifications and server-side reminder notifications.
5. **Mark Returned**, then rate each other 1-5 stars (peer trust). Watchers of CS301 on the **Wishlist** get an alert.

## Features
Must-have: listing and cataloguing, course-aware live search, 3-state workflow (plus reject), availability badges,
due-date reminders (banner, browser alert, in-app notification), My Books / Borrowing / History dashboard.
Stretch: ISBN barcode scanner (QuaggaJS) with Open Library auto-fill, peer trust ratings, department/course wishlist alerts.
(Lender-borrower chat is not implemented.)

## Architecture
```
server/src
  app.js            createApp(db, opts): helmet, CORS, body limit, routers, error handler
  config.js         business rules (LOAN_DAYS, SOON_DAYS, caps), exposed to the client via /api/config
  db.js             SQLite schema (constraints, indexes) + tx() helper
  services/         exchange.js (workflow rules), openLibrary.js (ISBN lookup, injectable fetch)
  routes/           auth, books, requests, misc (notifications, wishlist, isbn)
  queries.js        row -> API shape mapping (and e-mail masking)
  validators.js     input validation/normalisation
server/tests        exchange (service), validators, api (supertest end-to-end)
client/src          pages, components, context/AuthContext (JWT), hooks (useNow, dueState)
client/tests        unit tests for due-state logic
```

### Design decisions
- **Double-borrow prevention is enforced three ways:** an atomic `UPDATE ... WHERE status='available'` inside an
  `IMMEDIATE` transaction, plus a partial unique index allowing only one open request per book.
- **No cron:** overdue status is computed in the browser from `dueDate`; server reminders are generated lazily and
  idempotently (`dedupe_key`) whenever notifications are fetched.
- **Privacy:** contact e-mails are revealed only to the two parties once a request is approved; public book pages
  never expose request notes or borrower identity.
- **Security:** bcrypt password hashes, HS256 JWT (pinned algorithm, 12h expiry), per-route auth + ownership checks,
  login rate limiting, helmet headers, 10kb body limit, uniform login errors, demo-only endpoints disabled in production.

## API
| Method | Path | Auth |
|---|---|---|
| POST | /api/auth/register, /api/auth/login | no |
| GET | /api/auth/me | yes |
| GET | /api/config, /api/health | no |
| GET | /api/books, /api/books/:id | no |
| POST | /api/books | yes |
| PATCH / DELETE | /api/books/:id | owner |
| POST | /api/books/:id/request | yes |
| GET | /api/requests/mine | yes |
| POST | /api/requests/:id/approve, reject | lender |
| POST | /api/requests/:id/return | lender or borrower |
| POST | /api/requests/:id/review | lender or borrower (after return) |
| POST | /api/requests/:id/shift | dev only |
| GET / POST | /api/notifications, /api/notifications/read | yes |
| GET / POST / DELETE | /api/wishlist | yes |
| GET | /api/isbn/:isbn | yes (Open Library) |

## Known limitations
SQLite is a single-file database: fine for a campus pilot, and the schema is portable to PostgreSQL if you outgrow it.
Reminders are lazy (generated when a user's data is fetched), not pushed. Tokens live in localStorage; for a hardened
deployment use httpOnly cookies and HTTPS.
